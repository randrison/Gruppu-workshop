"use client";

import Script from "next/script";
import { useCallback, useEffect, useId, useRef, useState } from "react";

const googleTestSiteKey = "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI";

declare global {
  interface Window {
    grecaptcha?: {
      render: (container: string | HTMLElement, options: Record<string, unknown>) => number;
      reset: (widgetId?: number) => void;
      ready?: (callback: () => void) => void;
    };
  }
}

export default function RecaptchaV2({ onToken, compact = false }: { onToken: (token: string) => void; compact?: boolean }) {
  const reactId = useId().replaceAll(":", "");
  const containerId = `recaptcha-${reactId}`;
  const widgetId = useRef<number | undefined>(undefined);
  const [loaded, setLoaded] = useState(false);
  const siteKey = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY || googleTestSiteKey;

  const renderWidget = useCallback(() => {
    const captcha = window.grecaptcha;
    if (!captcha || typeof captcha.render !== "function" || widgetId.current !== undefined) return false;

    try {
      widgetId.current = captcha.render(containerId, {
        sitekey: siteKey,
        theme: "light",
        size: compact ? "compact" : "normal",
        callback: (token: string) => onToken(token),
        "expired-callback": () => onToken(""),
        "error-callback": () => onToken(""),
      });
      setLoaded(true);
      return true;
    } catch {
      return false;
    }
  }, [compact, containerId, onToken, siteKey]);

  useEffect(() => {
    let attempts = 0;
    const timer = window.setInterval(() => {
      attempts += 1;
      if (renderWidget() || attempts >= 40) window.clearInterval(timer);
    }, 250);

    return () => window.clearInterval(timer);
  }, [renderWidget]);

  return (
    <div className="recaptcha-field" aria-label="Proteção contra robôs">
      <Script src="https://www.google.com/recaptcha/api.js?render=explicit" strategy="afterInteractive" onLoad={() => { renderWidget(); }} />
      <div id={containerId} />
      {!loaded && <small>Carregando proteção…</small>}
    </div>
  );
}
