import { NextRequest, NextResponse } from "next/server";

async function validSession(value: string | undefined) {
  const secret = process.env.AUTH_SECRET;
  if (!value || !secret) return false;
  const [expiresAt, suppliedSignature] = value.split(".");
  if (!expiresAt || !suppliedSignature || Number(expiresAt) <= Date.now()) return false;

  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(expiresAt));
  const expected = Array.from(new Uint8Array(signature), (byte) => byte.toString(16).padStart(2, "0")).join("");
  return expected === suppliedSignature;
}

export async function middleware(request: NextRequest) {
  if (await validSession(request.cookies.get("gruppu_session")?.value)) return NextResponse.next();
  const loginUrl = new URL("/login", request.url);
  loginUrl.searchParams.set("next", request.nextUrl.pathname);
  return NextResponse.redirect(loginUrl);
}

export const config = { matcher: ["/app/:path*"] };
