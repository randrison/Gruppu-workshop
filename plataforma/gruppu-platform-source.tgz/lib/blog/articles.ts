export type BlogSection = {
  title: string;
  paragraphs: string[];
  bullets?: string[];
};

export type BlogArticle = {
  slug: string;
  category: string;
  title: string;
  description: string;
  excerpt: string;
  time: string;
  number: string;
  intro: string;
  sections: BlogSection[];
};

export const blogArticles: BlogArticle[] = [
  {
    slug: "como-melhorar-cardapio-ifood",
    category: "CARDÁPIO",
    title: "Como melhorar o cardápio no iFood: 7 ajustes para vender mais",
    description: "Veja sete ajustes práticos para organizar seu cardápio no iFood, facilitar a escolha do cliente e aumentar pedidos sem depender de desconto.",
    excerpt: "Ordem dos produtos, nomes, fotos, adicionais e combos que ajudam o cliente a decidir com mais facilidade.",
    time: "6 min",
    number: "01",
    intro: "Um bom cardápio não mostra apenas tudo o que a loja vende. Ele conduz o cliente até uma escolha clara, lucrativa e fácil de finalizar.",
    sections: [
      { title: "Comece pelos produtos que representam sua loja", paragraphs: ["Os primeiros itens recebem mais atenção. Coloque nessa área os produtos que têm boa saída, margem saudável e representam bem a experiência da loja."], bullets: ["Evite abrir o cardápio com categorias genéricas.", "Destaque poucos produtos principais.", "Use nomes fáceis de entender."] },
      { title: "Reduza o esforço para escolher", paragraphs: ["Descrições longas, adicionais repetidos e categorias demais criam dúvida. O cliente precisa entender rapidamente o que vem no pedido, para quantas pessoas serve e quais escolhas são realmente necessárias."] },
      { title: "Acompanhe antes de mudar tudo", paragraphs: ["Faça um ajuste por vez e compare visitas, conversão, ticket médio e quantidade de pedidos com o período anterior. Assim você descobre o que realmente funcionou."] },
    ],
  },
  {
    slug: "como-aumentar-ticket-medio-ifood",
    category: "VENDAS",
    title: "Como aumentar o ticket médio no iFood sem dar desconto",
    description: "Aprenda como calcular e aumentar o ticket médio no iFood usando combos, adicionais e organização do cardápio sem sacrificar sua margem.",
    excerpt: "Entenda o que esse indicador revela e como aumentar o valor de cada pedido com ofertas que fazem sentido.",
    time: "5 min",
    number: "02",
    intro: "Ticket médio é o valor médio gasto em cada pedido. Aumentá-lo não significa empurrar produtos, mas facilitar uma compra mais completa.",
    sections: [
      { title: "Calcule o ticket médio corretamente", paragraphs: ["Divida o faturamento do período pela quantidade de pedidos concluídos. Acompanhe o número toda semana e compare dias e horários semelhantes."] },
      { title: "Crie complementos que resolvem a refeição", paragraphs: ["Bebidas, sobremesas, porções e adicionais funcionam melhor quando aparecem no momento certo e têm relação direta com o produto principal."], bullets: ["Monte combos com economia real e margem protegida.", "Evite listas enormes de adicionais.", "Destaque o complemento mais escolhido."] },
      { title: "Observe margem, não apenas faturamento", paragraphs: ["Um ticket maior só é saudável quando também deixa mais dinheiro na operação. Considere CMV, comissão, promoções e custo de entrega ao avaliar cada mudança."] },
    ],
  },
  {
    slug: "metricas-ifood-para-restaurantes",
    category: "GESTÃO",
    title: "Métricas do iFood: 5 números para saber se sua loja dá lucro",
    description: "Conheça cinco métricas do iFood para acompanhar vendas, conversão, ticket médio, recompra e margem da sua operação.",
    excerpt: "Visitas, conversão, ticket, recompra e margem: um painel simples para saber onde agir primeiro.",
    time: "8 min",
    number: "03",
    intro: "Faturamento sozinho não mostra se a loja está crescendo de forma saudável. Alguns números precisam ser analisados juntos para indicar o próximo ajuste.",
    sections: [
      { title: "As cinco métricas essenciais", paragraphs: ["Acompanhe visitas, conversão, quantidade de pedidos, ticket médio e margem estimada. Recompra também ajuda a entender se a experiência faz o cliente voltar."], bullets: ["Visitas mostram alcance.", "Conversão mostra força do cardápio.", "Ticket mostra o tamanho médio da compra.", "Recompra mostra retenção.", "Margem mostra o resultado real."] },
      { title: "Leia os números em conjunto", paragraphs: ["Muitas visitas com poucos pedidos apontam um problema diferente de uma loja com boa conversão e ticket baixo. Evite tentar resolver todos os cenários com promoção."] },
      { title: "Transforme o painel em rotina", paragraphs: ["Escolha um dia fixo para registrar os indicadores e anotar mudanças realizadas. Um histórico simples ajuda a separar tendência de oscilação pontual."] },
    ],
  },
  {
    slug: "fotos-para-cardapio-ifood",
    category: "FOTOS",
    title: "Fotos para iFood: como deixar o cardápio mais atrativo",
    description: "Veja como criar fotos melhores para o cardápio do iFood e valorizar seus produtos com luz, enquadramento e consistência visual.",
    excerpt: "Luz, enquadramento e composição que ajudam o cliente a parar de rolar e abrir o produto.",
    time: "4 min",
    number: "04",
    intro: "A foto precisa mostrar com clareza o produto que chegará ao cliente. Uma imagem bonita, mas confusa ou diferente do pedido real, pode prejudicar a conversão e a confiança.",
    sections: [
      { title: "Priorize luz e fidelidade", paragraphs: ["Use luz lateral suave, fundo limpo e cores próximas do produto real. Evite filtros pesados e elementos que não acompanham o pedido."] },
      { title: "Mostre tamanho e textura", paragraphs: ["Escolha um ângulo que deixe visíveis os ingredientes principais e ajude o cliente a entender o tamanho da porção."], bullets: ["Mantenha o mesmo estilo entre as fotos.", "Evite textos pequenos dentro da imagem.", "Teste a miniatura no celular."] },
      { title: "Comece pelos campeões de venda", paragraphs: ["Não é necessário refazer todas as imagens de uma vez. Priorize capa, produtos mais visitados e itens com maior potencial de margem."] },
    ],
  },
  {
    slug: "promocoes-ifood-prejuizo",
    category: "PROMOÇÕES",
    title: "Promoções no iFood: como saber se você está perdendo dinheiro",
    description: "Entenda como avaliar promoções, cupons e campanhas no iFood para descobrir se elas geram lucro ou apenas aumentam pedidos sem margem.",
    excerpt: "Descubra quando a promoção deixou de ser estratégia e começou a comprometer margem e previsibilidade.",
    time: "7 min",
    number: "05",
    intro: "Uma promoção pode trazer volume e ainda piorar o caixa. O resultado depende do custo do produto, taxas, desconto financiado pela loja e comportamento de recompra.",
    sections: [
      { title: "Calcule o resultado por pedido", paragraphs: ["Subtraia CMV, comissão, pagamento online, entrega paga pela loja e participação na promoção. O que sobra precisa justificar o esforço operacional."] },
      { title: "Defina o objetivo antes de ativar", paragraphs: ["A campanha pode servir para atrair novos clientes, movimentar um horário fraco ou aumentar recompra. Sem objetivo e prazo, fica difícil saber quando parar."], bullets: ["Determine um orçamento máximo.", "Escolha produtos com margem compatível.", "Compare clientes novos e recorrentes."] },
      { title: "Não confunda pedido com crescimento", paragraphs: ["Mais pedidos não significam mais lucro. Compare o resultado líquido e a capacidade da operação antes e durante a campanha."] },
    ],
  },
  {
    slug: "analise-de-loja-no-ifood",
    category: "ANÁLISE",
    title: "Análise de loja no iFood: o que avaliar nos primeiros 10 minutos",
    description: "Use este roteiro para analisar uma loja no iFood e identificar problemas de cardápio, conversão, ticket e promoções.",
    excerpt: "Um roteiro direto para encontrar gargalos antes de mexer em preço, promoção ou investir em tráfego.",
    time: "5 min",
    number: "06",
    intro: "Uma análise rápida deve começar pela experiência do cliente e depois avançar para os números. Isso evita corrigir o sintoma enquanto o problema principal continua.",
    sections: [
      { title: "Primeiro: clareza da oferta", paragraphs: ["Veja se capa, nome, categorias e primeiros produtos deixam claro o que a loja vende e por que o cliente deveria escolher aquela opção."] },
      { title: "Depois: caminho até o pedido", paragraphs: ["Abra os principais produtos, leia descrições, teste adicionais e observe quantas decisões são exigidas antes de adicionar ao carrinho."], bullets: ["Cardápio fácil de navegar.", "Produtos principais bem posicionados.", "Adicionais simples e rentáveis.", "Preço coerente com a entrega."] },
      { title: "Por fim: números e prioridade", paragraphs: ["Cruze a experiência com visitas, conversão, ticket, promoções e margem. Escolha um gargalo principal e acompanhe o resultado do ajuste."] },
    ],
  },
];

export function getBlogArticle(slug: string) {
  return blogArticles.find((article) => article.slug === slug);
}
