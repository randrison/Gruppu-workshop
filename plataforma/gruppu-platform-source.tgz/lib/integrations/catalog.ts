export type IntegrationStatus = "ready" | "needs-key" | "planned";

export const integrationCatalog = [
  { id: "supabase", name: "Supabase", category: "Base do sistema", status: "needs-key" as const, purpose: "Login, banco de leads, clientes, lives, anotações e histórico.", env: ["SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY"] },
  { id: "resend", name: "Resend", category: "E-mail", status: "needs-key" as const, purpose: "Confirmações, lembretes de live, conteúdos e campanhas segmentadas.", env: ["RESEND_API_KEY", "RESEND_FROM_EMAIL"] },
  { id: "whatsapp", name: "WhatsApp da Gruppu", category: "Mensagens", status: "needs-key" as const, purpose: "Conector preparado para o provedor oficial usado pela Gruppu, com confirmação e lembretes.", env: ["WHATSAPP_PROVIDER", "WHATSAPP_API_BASE_URL", "WHATSAPP_ACCESS_TOKEN", "WHATSAPP_INSTANCE_ID"] },
  { id: "openai", name: "OpenAI", category: "Inteligência", status: "needs-key" as const, purpose: "Resumos de leads, sugestões de abordagem e apoio para analisar cardápios.", env: ["OPENAI_API_KEY"] },
  { id: "google", name: "Google Calendar + Meet", category: "Lives", status: "planned" as const, purpose: "Criar a agenda, guardar o link e importar presença quando o Workspace permitir.", env: ["GOOGLE_CLIENT_ID", "GOOGLE_CLIENT_SECRET", "GOOGLE_REDIRECT_URI"] },
  { id: "sheets", name: "Excel / Google Sheets", category: "Exportação", status: "ready" as const, purpose: "Exportação CSV já disponível; sincronização automática entra como integração opcional.", env: [] },
] as const;
