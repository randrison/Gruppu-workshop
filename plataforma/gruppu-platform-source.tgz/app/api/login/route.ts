import { createHmac, timingSafeEqual } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";

const attempts = new Map<string, { count: number; windowStartedAt: number; blockedUntil: number }>();
const WINDOW_MS = 15 * 60 * 1000;
const BLOCK_MS = 30 * 60 * 1000;
const MAX_ATTEMPTS = 10;

function clientIp(request: NextRequest) {
  return request.headers.get("cf-connecting-ip") || request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || request.headers.get("x-real-ip") || "unknown";
}

function safeEqual(left: string, right: string) {
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  return leftBuffer.length === rightBuffer.length && timingSafeEqual(leftBuffer, rightBuffer);
}

function signSession(expiresAt: number, secret: string) {
  const payload = String(expiresAt);
  const signature = createHmac("sha256", secret).update(payload).digest("hex");
  return `${payload}.${signature}`;
}

export async function POST(request: NextRequest) {
  const ip = clientIp(request);
  const now = Date.now();
  const current = attempts.get(ip) ?? { count: 0, windowStartedAt: now, blockedUntil: 0 };

  if (current.blockedUntil > now) {
    return NextResponse.json({ ok: false }, { status: 429, headers: { "Retry-After": String(Math.ceil((current.blockedUntil - now) / 1000)) } });
  }

  if (now - current.windowStartedAt > WINDOW_MS) {
    current.count = 0;
    current.windowStartedAt = now;
  }

  current.count += 1;
  if (current.count > MAX_ATTEMPTS) {
    current.blockedUntil = now + BLOCK_MS;
    attempts.set(ip, current);
    return NextResponse.json({ ok: false }, { status: 429, headers: { "Retry-After": String(BLOCK_MS / 1000) } });
  }
  attempts.set(ip, current);

  const body = await request.json().catch(() => ({}));
  const email = String(body.email ?? "").trim().toLowerCase();
  const password = String(body.password ?? "");
  const token = String(body.token ?? "");
  const secretKey = process.env.RECAPTCHA_SECRET_KEY;
  const adminEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const adminPassword = process.env.ADMIN_PASSWORD;
  const authSecret = process.env.AUTH_SECRET;

  if (!secretKey || !adminEmail || !adminPassword || !authSecret || !token) {
    return NextResponse.json({ ok: false }, { status: 503 });
  }

  const verification = await fetch("https://www.google.com/recaptcha/api/siteverify", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ secret: secretKey, response: token, remoteip: ip }),
  }).then((response) => response.json()).catch(() => ({ success: false }));

  if (!verification.success || !safeEqual(email, adminEmail) || !safeEqual(password, adminPassword)) {
    return NextResponse.json({ ok: false }, { status: 401 });
  }

  attempts.delete(ip);
  const expiresAt = now + 12 * 60 * 60 * 1000;
  const response = NextResponse.json({ ok: true });
  response.cookies.set("gruppu_session", signSession(expiresAt, authSecret), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 12 * 60 * 60,
  });
  return response;
}
