import { NextResponse } from "next/server";

const googleTestSecret = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe";

type LoginAttempt = { count: number; windowStartedAt: number; blockedUntil?: number };
const rateLimitStore = (globalThis as typeof globalThis & { gruppuLoginAttempts?: Map<string, LoginAttempt> });
const loginAttempts = rateLimitStore.gruppuLoginAttempts ?? new Map<string, LoginAttempt>();
rateLimitStore.gruppuLoginAttempts = loginAttempts;

const attemptWindowMs = 15 * 60 * 1000;
const blockDurationMs = 30 * 60 * 1000;

function getClientAddress(request: Request) {
  return request.headers.get("cf-connecting-ip")
    || request.headers.get("x-forwarded-for")?.split(",")[0]?.trim()
    || request.headers.get("x-real-ip")
    || "local";
}

function applyLoginRateLimit(request: Request) {
  const now = Date.now();
  const address = getClientAddress(request);
  const previous = loginAttempts.get(address);

  if (previous?.blockedUntil && previous.blockedUntil > now) {
    return Math.ceil((previous.blockedUntil - now) / 1000);
  }

  const current = !previous || now - previous.windowStartedAt > attemptWindowMs
    ? { count: 0, windowStartedAt: now }
    : previous;

  current.count += 1;
  if (current.count > 10) {
    current.blockedUntil = now + blockDurationMs;
    loginAttempts.set(address, current);
    return Math.ceil(blockDurationMs / 1000);
  }

  loginAttempts.set(address, current);
  return 0;
}

export async function POST(request: Request) {
  try {
    const body = await request.json() as { token?: string; purpose?: "login" | "lead" };
    if (!body.token) return NextResponse.json({ success: false, error: "Captcha ausente." }, { status: 400 });

    if (body.purpose === "login") {
      const retryAfter = applyLoginRateLimit(request);
      if (retryAfter > 0) {
        return NextResponse.json(
          { success: false, error: "Limite de tentativas atingido." },
          { status: 429, headers: { "retry-after": String(retryAfter), "cache-control": "no-store" } },
        );
      }
    }

    const secret = process.env.RECAPTCHA_SECRET_KEY || (process.env.NODE_ENV !== "production" ? googleTestSecret : "");
    if (!secret) return NextResponse.json({ success: false, error: "Captcha ainda não configurado no servidor." }, { status: 503 });

    const params = new URLSearchParams({ secret, response: body.token });
    const result = await fetch("https://www.google.com/recaptcha/api/siteverify", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: params,
      cache: "no-store",
    });
    const verification = await result.json() as { success?: boolean; [key: string]: unknown };
    return NextResponse.json({ success: verification.success === true }, { status: verification.success ? 200 : 400 });
  } catch {
    return NextResponse.json({ success: false, error: "Não foi possível validar o captcha." }, { status: 500 });
  }
}
