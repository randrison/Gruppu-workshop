"use client";

import { FormEvent, useCallback, useState } from "react";
import RecaptchaV2 from "@/components/recaptcha-v2";

export default function LoginForm() {
  const [captchaToken, setCaptchaToken] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const handleCaptcha = useCallback((token: string) => setCaptchaToken(token), []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    if (!captchaToken) return setError("Confirme que você não é um robô.");
    setLoading(true);
    const response = await fetch("/api/recaptcha", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ token: captchaToken, purpose: "login" }) });
    if (!response.ok) {
      setLoading(false);
      if (response.status === 429) {
        setError("Muitas tentativas neste acesso. Aguarde 30 minutos antes de tentar novamente.");
        return;
      }
      setError("Não foi possível validar a proteção. Atualize a página e tente novamente.");
      return;
    }
    window.location.href = "/app";
  }

  return <form onSubmit={submit}>
    <span className="login-step">GRUPPU ADM</span>
    <h2>Bem-vindo de volta.</h2>
    <p>Entre para acompanhar a operação comercial da Gruppu.</p>
    <label htmlFor="login-email">E-mail</label>
    <input id="login-email" type="email" autoComplete="username" placeholder="seuemail@gruppu.com.br" required />
    <label htmlFor="login-password">Senha</label>
    <input id="login-password" type="password" autoComplete="current-password" placeholder="Sua senha" required />
    <RecaptchaV2 onToken={handleCaptcha} compact />
    {error && <p className="field-error login-error" role="alert">{error}</p>}
    <button type="submit" disabled={loading}><span>{loading ? "VALIDANDO…" : "ENTRAR NO PAINEL"}</span><span>→</span></button>
    <small>Proteção ativa contra robôs e excesso de tentativas. Após 10 verificações, o acesso fica bloqueado por 30 minutos.</small>
  </form>;
}
