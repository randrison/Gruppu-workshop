import type { Metadata } from "next";
import Link from "next/link";
import LoginForm from "./login-form";

export const metadata: Metadata = { title: "Gruppu ADM | Acesso ao painel" };

export default function LoginPage() {
  return (
    <main className="login-shell">
      <section className="login-brand-panel">
        <Link className="crm-logo" href="/">GRUPPU<span>.</span></Link>
        <div>
          <span className="login-kicker">GRUPPU ADM · ACESSO RESTRITO</span>
          <h1>Do cadastro ao contrato. <em>Tudo em um só lugar.</em></h1>
          <p>Acompanhe leads, lives e resultados em um ambiente reservado para a equipe autorizada da Gruppu.</p>
        </div>
        <div className="login-proof"><strong>0</strong><span>dados iniciais; comece sua operação do zero</span></div>
      </section>

      <section className="login-form-panel">
        <LoginForm />
      </section>
    </main>
  );
}
