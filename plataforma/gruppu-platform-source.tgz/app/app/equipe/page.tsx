import type { Metadata } from "next";
import DashboardShell from "../_components/dashboard-shell";
import TeamManager from "./team-manager";

export const metadata: Metadata = { title: "Equipe e acessos | Painel Gruppu" };
export default function TeamPage() { return <DashboardShell active="team" eyebrow="ACESSO E SEGURANÇA" title="Equipe e permissões"><TeamManager /></DashboardShell>; }
