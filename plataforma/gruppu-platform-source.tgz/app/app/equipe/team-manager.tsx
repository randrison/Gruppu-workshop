"use client";

import { FormEvent, useEffect, useState } from "react";
import { recordAuditLog } from "@/lib/crm/audit-store";

type Member = { id: string; name: string; email: string; role: string; status: "Convite preparado" | "Ativo"; permissions: string[] };
const key = "gruppu.crm.team.v2";
const permissionOptions = ["Ver visão geral", "Gerenciar leads", "Gerenciar clientes", "Criar lives", "Enviar e-mails", "Ver financeiro", "Gerenciar equipe", "Ver logs"];
const roleDefaults: Record<string, string[]> = {
  Administrador: permissionOptions,
  Comercial: ["Ver visão geral", "Gerenciar leads", "Gerenciar clientes", "Criar lives", "Enviar e-mails"],
  Operação: ["Ver visão geral", "Gerenciar clientes", "Criar lives"],
  Conteúdo: ["Ver visão geral", "Criar lives", "Enviar e-mails"],
  Financeiro: ["Ver visão geral", "Gerenciar clientes", "Ver financeiro"],
};

export default function TeamManager() {
  const [members, setMembers] = useState<Member[]>([]);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState(""); const [email, setEmail] = useState(""); const [role, setRole] = useState("Comercial");
  useEffect(() => { const saved = localStorage.getItem(key); if (saved) queueMicrotask(() => setMembers(JSON.parse(saved) as Member[])); }, []);
  function persist(next: Member[]) { setMembers(next); localStorage.setItem(key, JSON.stringify(next)); }
  function invite(event: FormEvent) { event.preventDefault(); const member: Member = { id: crypto.randomUUID(), name, email, role, status: "Convite preparado", permissions: roleDefaults[role] || [] }; persist([member, ...members]); recordAuditLog({ action: "Acesso de funcionário preparado", entity: name, details: `${role} · ${email}` }); setName(""); setEmail(""); setOpen(false); }
  function togglePermission(member: Member, permission: string) { const permissions = member.permissions.includes(permission) ? member.permissions.filter((item) => item !== permission) : [...member.permissions, permission]; persist(members.map((item) => item.id === member.id ? { ...item, permissions } : item)); recordAuditLog({ action: "Permissão alterada", entity: member.name, details: permission }); }
  function remove(member: Member) { if (!confirm(`Remover o acesso preparado para ${member.name}?`)) return; persist(members.filter((item) => item.id !== member.id)); recordAuditLog({ action: "Acesso removido", entity: member.name, details: member.email }); }
  return <><section className="crm-page-intro integration-intro"><div><p>Defina exatamente o que cada funcionário poderá ver e alterar. Os convites reais serão enviados quando o login do Supabase estiver conectado.</p></div><strong>{members.length}</strong><span>acessos preparados</span></section><section className="crm-panel team-panel"><div className="crm-panel-head"><div><span>CONTROLE DE ACESSO</span><h2>Funcionários e funções</h2></div><button className="crm-secondary-button" onClick={() => setOpen(true)}>+ Adicionar funcionário</button></div>{members.length === 0 ? <div className="empty-state">Nenhum funcionário adicionado. Você começa como administrador.</div> : <div className="team-list">{members.map((member) => <article key={member.id}><div className="team-member-head"><span className="crm-avatar">{member.name.slice(0,2).toUpperCase()}</span><div><strong>{member.name}</strong><small>{member.email} · {member.role}</small></div><b>{member.status}</b><button onClick={() => remove(member)}>Remover</button></div><div className="permission-grid">{permissionOptions.map((permission) => <label key={permission}><input type="checkbox" checked={member.permissions.includes(permission)} onChange={() => togglePermission(member, permission)} />{permission}</label>)}</div></article>)}</div>}</section>{open && <div className="crm-modal-backdrop" onMouseDown={() => setOpen(false)}><form className="crm-modal" onMouseDown={(event) => event.stopPropagation()} onSubmit={invite}><button type="button" className="crm-modal-close" onClick={() => setOpen(false)}>×</button><span>NOVO ACESSO</span><h2>Adicionar funcionário</h2><label>Nome<input value={name} onChange={(event) => setName(event.target.value)} required /></label><label>E-mail<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required /></label><label>Função<select value={role} onChange={(event) => setRole(event.target.value)}>{Object.keys(roleDefaults).map((item) => <option key={item}>{item}</option>)}</select></label><p>Você poderá ajustar cada permissão individualmente depois.</p><button type="submit">Preparar acesso</button></form></div>}</>;
}
