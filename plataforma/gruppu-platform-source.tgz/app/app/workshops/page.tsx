import type { Metadata } from "next";
import DashboardShell from "../_components/dashboard-shell";
import LivesManager from "./lives-manager";

export const metadata: Metadata = { title: "Lives | Painel Gruppu" };
export default function WorkshopsPage() { return <DashboardShell active="workshops" eyebrow="WORKSHOPS E TRANSMISSÕES" title="Lives e presença"><LivesManager /></DashboardShell>; }
