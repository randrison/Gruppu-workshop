import type { Metadata } from "next";
import Link from "next/link";
import DashboardShell from "./_components/dashboard-shell";
import { demoLeads, funnel } from "./demo-data";

export const metadata: Metadata = { title: "Visão geral | Painel Gruppu" };

export default function DashboardPage() {
  return (
    <DashboardShell active="dashboard" eyebrow="CENTRAL DE OPERAÇÕES" title="Visão geral da Gruppu">
      <section className="crm-welcome-strip">
        <div><span className="crm-live-pulse" />PRÓXIMA LIVE · HOJE ÀS 16H</div>
        <p><strong>0 inscritos</strong> aguardando a primeira live cadastrada.</p>
        <Link href="/app/workshops">Preparar transmissão <span>→</span></Link>
      </section>

      <section className="crm-metrics" aria-label="Indicadores principais">
        <article><span>CLIENTES ATIVOS</span><strong>0</strong><small>Comece cadastrando seu primeiro cliente</small></article>
        <article><span>RECEITA MENSAL ATIVA</span><strong>R$ 0</strong><small>Edite após cadastrar contratos</small></article>
        <article><span>TICKET MÉDIO</span><strong>R$ 0</strong><small>Sem valores lançados</small></article>
        <article className="metric-red"><span>VENDAS FECHADAS NO MÊS</span><strong>R$ 0</strong><small>Nenhum valor lançado</small></article>
      </section>

      <section className="crm-grid-two">
        <article className="crm-panel">
          <div className="crm-panel-head"><div><span>FUNIL DO WORKSHOP</span><h2>Da captura ao cliente</h2></div><small>Últimos 30 dias</small></div>
          <div className="funnel-list">
            {funnel.map((item, index) => (
              <div key={item.label}>
                <span className="funnel-index">0{index + 1}</span>
                <div><p><strong>{item.label}</strong><b>{item.value}</b></p><i><span style={{ width: `${item.percent}%` }} /></i></div>
                <small>{item.percent}%</small>
              </div>
            ))}
          </div>
        </article>

        <article className="crm-panel crm-recent">
          <div className="crm-panel-head"><div><span>ENTRADAS RECENTES</span><h2>Novos leads</h2></div><Link href="/app/leads">Ver todos →</Link></div>
          <div className="recent-list">
            {demoLeads.slice(0, 4).map((lead) => (
              <Link key={lead.id} href={`/app/leads/${lead.id}`}>
                <span className="lead-avatar">{lead.initials}</span>
                <div><strong>{lead.name}</strong><small>{lead.source} · {lead.registeredAt}</small></div>
                <b className={`status status-${lead.status.toLowerCase().replaceAll(" ", "-")}`}>{lead.status}</b>
              </Link>
            ))}
            {demoLeads.length === 0 && <p className="empty-state">Os novos cadastros aparecerão aqui.</p>}
          </div>
        </article>
      </section>

      <section className="crm-bottom-grid">
        <article className="crm-panel crm-channel">
          <div className="crm-panel-head"><div><span>AQUISIÇÃO</span><h2>De onde eles vêm</h2></div></div>
          <div className="channel-row"><span>Instagram</span><i><b style={{ width: "0%" }} /></i><strong>0</strong></div>
          <div className="channel-row"><span>Google orgânico</span><i><b style={{ width: "0%" }} /></i><strong>0</strong></div>
          <div className="channel-row"><span>Indicação</span><i><b style={{ width: "0%" }} /></i><strong>0</strong></div>
          <div className="channel-row"><span>Blog</span><i><b style={{ width: "0%" }} /></i><strong>0</strong></div>
        </article>
        <article className="crm-panel crm-task-panel">
          <span>PRÓXIMA AÇÃO RECOMENDADA</span>
          <h2>Cadastre a primeira live e acompanhe tudo daqui.</h2>
          <p>Depois da integração, o sistema poderá preparar lembretes por WhatsApp e e-mail.</p>
          <Link href="/app/workshops"><span>Criar primeira live</span><span>↗</span></Link>
        </article>
      </section>
    </DashboardShell>
  );
}
