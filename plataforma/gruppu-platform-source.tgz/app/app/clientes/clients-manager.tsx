"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import type { CrmClient } from "../demo-data";
import ExportButton from "../_components/export-button";
import { recordAuditLog } from "@/lib/crm/audit-store";

const clientsKey = "gruppu.crm.clients.v3";
const emptyClient: CrmClient = { id: "", company: "", contact: "", email: "", phone: "", plan: "", billingCycle: "Mensal", monthly: 0, totalPaid: 0, start: "", status: "Ativo", result: "R$ 0" };
const currency = (value: number) => value.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });

export default function ClientsManager() {
  const [clients, setClients] = useState<CrmClient[]>([]);
  const [editing, setEditing] = useState<CrmClient | null>(null);

  useEffect(() => {
    const saved = window.localStorage.getItem(clientsKey);
    if (saved) queueMicrotask(() => setClients(JSON.parse(saved) as CrmClient[]));
  }, []);

  function persist(next: CrmClient[]) { setClients(next); window.localStorage.setItem(clientsKey, JSON.stringify(next)); }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!editing) return;
    const client = editing.id ? editing : { ...editing, id: crypto.randomUUID() };
    const exists = clients.some((item) => item.id === client.id);
    persist(exists ? clients.map((item) => item.id === client.id ? client : item) : [client, ...clients]);
    recordAuditLog({ action: exists ? "Cliente atualizado" : "Cliente criado", entity: client.company, details: `${client.billingCycle} · ${currency(client.monthly)}` });
    setEditing(null);
  }

  function remove(client: CrmClient) {
    if (!window.confirm(`Excluir ${client.company}? Esta ação remove o registro deste ambiente local.`)) return;
    persist(clients.filter((item) => item.id !== client.id));
    recordAuditLog({ action: "Cliente excluído", entity: client.company, details: "Registro removido da carteira" });
  }

  const total = useMemo(() => clients.reduce((sum, client) => sum + client.monthly, 0), [clients]);
  const totalPaid = useMemo(() => clients.reduce((sum, client) => sum + client.totalPaid, 0), [clients]);
  const active = clients.filter((client) => client.status === "Ativo").length;

  return <>
    <section className="crm-metrics client-metrics"><article><span>CLIENTES ATIVOS</span><strong>{active}</strong><small>Carteira cadastrada</small></article><article><span>RECEITA MENSAL</span><strong>{currency(total)}</strong><small>Contratos recorrentes</small></article><article><span>TOTAL JÁ PAGO</span><strong>{currency(totalPaid)}</strong><small>Atualizado manualmente ou por integração</small></article><article className="metric-red"><span>CHURN NO MÊS</span><strong>0%</strong><small>Nenhum cancelamento lançado</small></article></section>
    <section className="crm-panel clients-panel"><div className="crm-panel-head"><div><span>CONTRATOS DA GRUPPU</span><h2>Clientes acompanhados</h2></div><div className="client-panel-actions"><button className="crm-secondary-button" onClick={() => setEditing({ ...emptyClient })}>+ Novo cliente</button><ExportButton rows={clients as unknown as Record<string, unknown>[]} fileName="clientes-gruppu.csv" label="Exportar clientes" columns={[{ key: "company", label: "Empresa" }, { key: "contact", label: "Contato" }, { key: "email", label: "E-mail" }, { key: "phone", label: "Telefone" }, { key: "plan", label: "Plano" }, { key: "billingCycle", label: "Cobrança" }, { key: "monthly", label: "Valor mensal" }, { key: "totalPaid", label: "Total pago" }, { key: "start", label: "Início" }, { key: "status", label: "Status" }]} /></div></div><div className="leads-table-wrap"><table><thead><tr><th>EMPRESA</th><th>PLANO</th><th>COBRANÇA</th><th>VALOR</th><th>TOTAL PAGO</th><th>STATUS</th><th>AÇÕES</th></tr></thead><tbody>{clients.map((client) => <tr key={client.id}><td><div className="client-name"><span>{client.company.slice(0, 2).toUpperCase()}</span><div><strong>{client.company}</strong><small>{client.contact}</small></div></div></td><td>{client.plan || "—"}</td><td>{client.billingCycle}</td><td><strong>{currency(client.monthly)}</strong></td><td>{currency(client.totalPaid)}</td><td><b className={client.status === "Ativo" ? "status status-qualificado" : "status status-novo"}>{client.status}</b></td><td><div className="table-row-actions"><button onClick={() => setEditing({ ...client })}>Editar</button><button className="danger" onClick={() => remove(client)}>Excluir</button></div></td></tr>)}</tbody></table>{clients.length === 0 && <div className="empty-state">Nenhum cliente cadastrado. Use “Novo cliente” para começar.</div>}</div></section>
    {editing && <div className="crm-modal-backdrop" onMouseDown={() => setEditing(null)}><form className="crm-modal client-editor" onMouseDown={(event) => event.stopPropagation()} onSubmit={submit}><button type="button" className="crm-modal-close" onClick={() => setEditing(null)}>×</button><span>FICHA DO CLIENTE</span><h2>{editing.id ? "Editar cliente" : "Novo cliente"}</h2><div className="client-editor-grid"><label>Nome da empresa<input value={editing.company} onChange={(event) => setEditing({ ...editing, company: event.target.value })} required /></label><label>Responsável<input value={editing.contact} onChange={(event) => setEditing({ ...editing, contact: event.target.value })} /></label><label>E-mail<input type="email" value={editing.email} onChange={(event) => setEditing({ ...editing, email: event.target.value })} /></label><label>Telefone<input value={editing.phone} onChange={(event) => setEditing({ ...editing, phone: event.target.value })} /></label><label>Plano<input value={editing.plan} onChange={(event) => setEditing({ ...editing, plan: event.target.value })} /></label><label>Ciclo de cobrança<select value={editing.billingCycle} onChange={(event) => setEditing({ ...editing, billingCycle: event.target.value as CrmClient["billingCycle"] })}><option>Mensal</option><option>Trimestral</option><option>Semestral</option><option>Anual</option></select></label><label>Valor mensal equivalente<input type="number" min="0" value={editing.monthly} onChange={(event) => setEditing({ ...editing, monthly: Number(event.target.value) || 0 })} /></label><label>Total já pago<input type="number" min="0" value={editing.totalPaid} onChange={(event) => setEditing({ ...editing, totalPaid: Number(event.target.value) || 0 })} /></label><label>Data de início<input type="date" value={editing.start} onChange={(event) => setEditing({ ...editing, start: event.target.value })} /></label><label>Status<select value={editing.status} onChange={(event) => setEditing({ ...editing, status: event.target.value })}><option>Ativo</option><option>Em implantação</option><option>Pausado</option><option>Encerrado</option></select></label></div><button type="submit">Salvar cliente</button></form></div>}
  </>;
}
