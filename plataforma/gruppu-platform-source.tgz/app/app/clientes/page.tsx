import type { Metadata } from "next";
import DashboardShell from "../_components/dashboard-shell";
import ClientsManager from "./clients-manager";

export const metadata: Metadata = { title: "Clientes | Painel Gruppu" };

export default function ClientsPage() {
  return <DashboardShell active="clients" eyebrow="CARTEIRA DE CONTRATOS" title="Clientes e receita"><ClientsManager /></DashboardShell>;
}
