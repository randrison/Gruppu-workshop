import DashboardShell from "../../_components/dashboard-shell";
import { demoLeads } from "../../demo-data";
import Link from "next/link";
import LeadDetailPanel from "./lead-detail-panel";

export function generateStaticParams() { return demoLeads.map((lead) => ({ id: lead.id })); }

export default async function LeadDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const lead = demoLeads.find((item) => item.id === id);
  return (
    <DashboardShell active="leads" eyebrow="FICHA DO CONTATO" title={lead?.name ?? "Novo contato"}>
      <Link className="crm-back" href="/app/leads">← Voltar para todos os leads</Link>
      <LeadDetailPanel lead={lead} leadId={id} />
    </DashboardShell>
  );
}
