import type { Metadata } from "next";
import DashboardShell from "../_components/dashboard-shell";
import { demoLeads } from "../demo-data";
import LeadsTable from "./leads-table";

export const metadata: Metadata = { title: "Leads | Painel Gruppu" };

export default function LeadsPage() {
  return (
    <DashboardShell active="leads" eyebrow="CENTRAL COMERCIAL" title="Leads e oportunidades">
      <section className="crm-page-intro"><p>Veja quem se cadastrou, de onde veio e qual é o próximo passo para avançar a conversa.</p><div><strong>0</strong><span>dados iniciais</span></div></section>
      <LeadsTable leads={demoLeads} />
    </DashboardShell>
  );
}
