import type { Metadata } from "next";
import DashboardShell from "../_components/dashboard-shell";
import AuditLogPanel from "./audit-log-panel";

export const metadata: Metadata = { title: "Histórico de alterações | Painel Gruppu" };
export default function LogsPage() { return <DashboardShell active="logs" eyebrow="AUDITORIA DO SISTEMA" title="Histórico de alterações"><AuditLogPanel /></DashboardShell>; }
