import type { Metadata } from "next";
import DashboardShell from "../_components/dashboard-shell";
import EmailMarketingPanel from "./email-marketing-panel";

export const metadata: Metadata = { title: "E-mail marketing | Painel Gruppu" };
export default function EmailPage() { return <DashboardShell active="email" eyebrow="COMUNICAÇÃO E CONTEÚDO" title="E-mail marketing"><EmailMarketingPanel /></DashboardShell>; }
