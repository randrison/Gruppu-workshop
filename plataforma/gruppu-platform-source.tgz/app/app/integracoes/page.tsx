import type { Metadata } from "next";
import DashboardShell from "../_components/dashboard-shell";
import IntegrationsManager from "./integrations-manager";

export const metadata: Metadata = { title: "Integrações | Painel Gruppu" };

export default function IntegrationsPage() {
  return <DashboardShell active="integrations" eyebrow="CENTRAL DE CONEXÕES" title="Integrações e automações"><IntegrationsManager /></DashboardShell>;
}
