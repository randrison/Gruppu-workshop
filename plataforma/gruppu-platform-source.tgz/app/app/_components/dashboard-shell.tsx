"use client";

import type { ReactNode } from "react";
import { useEffect, useState } from "react";
import Link from "next/link";

const navItems = [
  { href: "/app", label: "Visão geral", icon: "⌂", key: "dashboard" },
  { href: "/app/leads", label: "Leads", icon: "◎", key: "leads" },
  { href: "/app/clientes", label: "Clientes", icon: "◇", key: "clients" },
  { href: "/app/workshops", label: "Lives", icon: "▶", key: "workshops" },
  { href: "/app/email", label: "E-mail", icon: "✉", key: "email" },
  { href: "/app/equipe", label: "Equipe", icon: "♙", key: "team" },
  { href: "/app/logs", label: "Logs", icon: "≡", key: "logs" },
  { href: "/app/integracoes", label: "Integrações", icon: "⚙", key: "integrations" },
];

const quickItems = navItems.slice(0, 4);

export default function DashboardShell({
  active,
  title,
  eyebrow,
  children,
}: {
  active: string;
  title: string;
  eyebrow: string;
  children: ReactNode;
}) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    function closeOnEscape(event: KeyboardEvent) {
      if (event.key === "Escape") setMobileMenuOpen(false);
    }
    window.addEventListener("keydown", closeOnEscape);
    return () => window.removeEventListener("keydown", closeOnEscape);
  }, []);

  return (
    <main className="crm-shell">
      <button
        type="button"
        className={`crm-menu-backdrop ${mobileMenuOpen ? "visible" : ""}`}
        aria-label="Fechar menu"
        tabIndex={mobileMenuOpen ? 0 : -1}
        onClick={() => setMobileMenuOpen(false)}
      />

      <aside className={`crm-sidebar ${mobileMenuOpen ? "mobile-open" : ""}`} id="crm-full-menu">
        <div className="crm-sidebar-mobile-head">
          <Link className="crm-logo" href="/" aria-label="Gruppu — início">GRUPPU<span>.</span></Link>
          <button type="button" aria-label="Fechar menu" onClick={() => setMobileMenuOpen(false)}>×</button>
        </div>
        <Link className="crm-logo crm-logo-desktop" href="/" aria-label="Gruppu — início">GRUPPU<span>.</span></Link>
        <nav aria-label="Menu completo do painel">
          {navItems.map((item) => (
            <Link
              key={item.key}
              href={item.href}
              className={active === item.key ? "active" : ""}
              onClick={() => setMobileMenuOpen(false)}
            >
              <i aria-hidden="true">{item.icon}</i><span>{item.label}</span>
            </Link>
          ))}
        </nav>
        <div className="crm-sidebar-footer">
          <span className="crm-avatar">GR</span>
          <div><strong>Equipe Gruppu</strong><small>Administrador</small></div>
          <Link href="/api/logout" aria-label="Sair">↗</Link>
        </div>
      </aside>

      <section className="crm-main">
        <header className="crm-topbar">
          <div><span>{eyebrow}</span><h1>{title}</h1></div>
          <div className="crm-top-actions">
            <button aria-label="Notificações">●</button>
          </div>
        </header>
        <div className="crm-content">{children}</div>
      </section>

      <nav className="crm-mobile-nav" aria-label="Atalhos do aplicativo">
        {quickItems.map((item) => (
          <Link key={item.key} href={item.href} className={active === item.key ? "active" : ""}>
            <i aria-hidden="true">{item.icon}</i><span>{item.label}</span>
          </Link>
        ))}
        <button
          type="button"
          className={mobileMenuOpen || !quickItems.some((item) => item.key === active) ? "active" : ""}
          aria-expanded={mobileMenuOpen}
          aria-controls="crm-full-menu"
          onClick={() => setMobileMenuOpen(true)}
        >
          <i aria-hidden="true">☰</i><span>Menu</span>
        </button>
      </nav>
    </main>
  );
}
