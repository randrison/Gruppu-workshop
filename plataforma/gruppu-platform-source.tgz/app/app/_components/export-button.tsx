"use client";

type ExportColumn = { key: string; label: string };

function escapeCsv(value: unknown) {
  const text = String(value ?? "");
  return `"${text.replaceAll('"', '""')}"`;
}

export default function ExportButton({ rows, columns, fileName, label = "Exportar Excel/CSV" }: { rows: Record<string, unknown>[]; columns: ExportColumn[]; fileName: string; label?: string }) {
  function download() {
    const csv = [columns.map((column) => escapeCsv(column.label)).join(","), ...rows.map((row) => columns.map((column) => escapeCsv(row[column.key])).join(","))].join("\n");
    const blob = new Blob([`\ufeff${csv}`], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = fileName;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  return <button className="crm-secondary-button" type="button" onClick={download}>{label} <span>↓</span></button>;
}
