import type { Metadata } from "next";
import { headers } from "next/headers";
import "./globals.css";
import PwaRegister from "./pwa-register";

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host = requestHeaders.get("host") ?? "gruppu-workshop-ifood.openai.site";
  const protocol = requestHeaders.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  const imageUrl = `${protocol}://${host}/og.png`;

  return {
    title: "Análise de loja ao vivo | Venda mais no iFood — Gruppu",
    description:
      "Participe da análise gratuita da Gruppu e descubra como aumentar vendas, lucro e previsibilidade no iFood sem depender de promoções.",
    icons: {
      icon: [
        { url: "/favicon.svg", type: "image/svg+xml" },
        { url: "/icons/gruppu-192.png", type: "image/png", sizes: "192x192" },
      ],
      shortcut: "/icons/gruppu-192.png",
      apple: [{ url: "/icons/gruppu-180.png", type: "image/png", sizes: "180x180" }],
    },
    manifest: "/manifest.webmanifest",
    appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "Gruppu" },
    openGraph: {
      title: "Análise de loja ao vivo — Gruppu",
      description: "Descubra como vender R$20 mil a mais no iFood sem depender de promoções.",
      images: [{ url: imageUrl, width: 1200, height: 630, alt: "Análise de loja ao vivo da Gruppu" }],
    },
    twitter: {
      card: "summary_large_image",
      title: "Análise de loja ao vivo — Gruppu",
      description: "Descubra como vender R$20 mil a mais no iFood sem depender de promoções.",
      images: [imageUrl],
    },
  };
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body>
        <PwaRegister />
        {children}
      </body>
    </html>
  );
}
