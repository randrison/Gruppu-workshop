import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Política de Privacidade | Gruppu",
  description: "Saiba como a Gruppu coleta, utiliza, protege e elimina dados pessoais.",
  alternates: { canonical: "https://gruppu.com.br/politica-de-privacidade" },
};

export default function PrivacyPage() {
  return (
    <main className="legal-page">
      <Link className="brand" href="/">GRUPPU<span className="brand-dot">.</span></Link>
      <article>
        <span>PRIVACIDADE, TRANSPARÊNCIA E LGPD</span>
        <h1>Política de Privacidade</h1>
        <p className="legal-intro">
          Esta Política explica, de forma objetiva, como a Gruppu trata os dados
          pessoais enviados em seus sites, formulários, análises ao vivo e canais de atendimento.
        </p>

        <section className="legal-company-card" aria-label="Identificação da empresa">
          <div><small>CONTROLADOR DOS DADOS</small><strong>Gruppu Gruppu LTDA</strong></div>
          <div><small>CNPJ</small><strong>55.404.170/0001-23</strong></div>
          <address>Avenida Paulista, 302, Conj. 10<br />Bela Vista · São Paulo/SP · CEP 01310-000</address>
        </section>

        <h2>1. Quais dados podemos coletar</h2>
        <p>
          Podemos receber nome, telefone, e-mail, faixa de faturamento, objetivos informados,
          dados sobre a empresa ou loja e registros de interação. Também podemos registrar dados
          técnicos necessários à segurança e à medição de origem, como endereço IP, página acessada,
          data, horário, navegador, referência da visita e parâmetros de campanha.
        </p>

        <h2>2. Como os dados são obtidos</h2>
        <p>
          Os dados são obtidos quando você preenche um formulário, solicita uma análise,
          participa de uma live, conversa com a equipe ou utiliza nossas páginas e ferramentas.
          Alguns dados técnicos podem ser gerados automaticamente durante a navegação.
        </p>

        <h2>3. Para quais finalidades usamos</h2>
        <ul>
          <li>Confirmar o cadastro e enviar o link, avisos e materiais da análise ao vivo;</li>
          <li>Responder solicitações e realizar o acompanhamento comercial autorizado;</li>
          <li>Entender interesses, origem dos cadastros e desempenho das páginas;</li>
          <li>Personalizar conteúdos e comunicações compatíveis com a autorização concedida;</li>
          <li>Prevenir fraude, abuso, acessos automatizados e incidentes de segurança;</li>
          <li>Cumprir obrigações legais e exercer direitos em processos administrativos ou judiciais.</li>
        </ul>

        <h2>4. Bases legais e consentimento</h2>
        <p>
          Conforme a finalidade, o tratamento pode se apoiar no consentimento, na execução de
          procedimentos solicitados por você, no legítimo interesse, no cumprimento de obrigação
          legal ou no exercício regular de direitos. Quando o tratamento depender de consentimento,
          você poderá revogá-lo pelos canais oficiais da Gruppu.
        </p>

        <h2>5. Cookies, métricas e proteção contra robôs</h2>
        <p>
          Podemos utilizar recursos estritamente necessários ao funcionamento e à segurança do site,
          inclusive reCAPTCHA. Ferramentas de métricas e publicidade poderão registrar a origem e a
          interação com as páginas conforme as configurações aplicáveis. O bloqueio de cookies no
          navegador pode limitar algumas funcionalidades.
        </p>

        <h2>6. WhatsApp e serviços de terceiros</h2>
        <p>
          Ao escolher entrar em um grupo ou iniciar uma conversa, você será direcionado ao WhatsApp.
          E-mail, hospedagem, banco de dados, mensageria, análise e segurança podem ser processados por
          fornecedores contratados, somente na medida necessária para prestar esses serviços. Esses
          ambientes também possuem políticas próprias. A Gruppu não comercializa dados pessoais.
        </p>

        <h2>7. Armazenamento, retenção e segurança</h2>
        <p>
          Aplicamos medidas técnicas e administrativas razoáveis para proteger os dados contra acesso,
          alteração, perda ou divulgação não autorizada. Os dados são mantidos pelo período necessário
          às finalidades informadas, ao relacionamento com o titular e às obrigações legais. Depois,
          poderão ser eliminados ou anonimizados, salvo quando a conservação for permitida por lei.
        </p>

        <h2>8. Seus direitos</h2>
        <p>Nos termos da legislação aplicável, você pode solicitar:</p>
        <ul>
          <li>Confirmação da existência de tratamento e acesso aos dados;</li>
          <li>Correção de informações incompletas, inexatas ou desatualizadas;</li>
          <li>Anonimização, bloqueio ou eliminação quando cabível;</li>
          <li>Informações sobre compartilhamento e sobre as consequências de não consentir;</li>
          <li>Revogação do consentimento e oposição a tratamentos, quando aplicável;</li>
          <li>Revisão de decisões tomadas unicamente por tratamento automatizado, quando houver.</li>
        </ul>
        <p>
          Para proteger o próprio titular, a Gruppu poderá solicitar informações adicionais para
          confirmar a identidade antes de atender ao pedido.
        </p>

        <h2>9. Comunicações e cancelamento</h2>
        <p>
          Você pode cancelar comunicações a qualquer momento pelo mecanismo indicado na mensagem ou
          solicitando o descadastro pelos canais oficiais da Gruppu. Mensagens essenciais sobre uma
          solicitação em andamento poderão continuar sendo enviadas enquanto necessárias.
        </p>

        <h2>10. Atualizações desta Política</h2>
        <p>
          Esta Política poderá ser atualizada para refletir mudanças legais, operacionais ou de
          segurança. A versão vigente estará sempre disponível nesta página, com a data da revisão.
        </p>

        <section className="legal-contact-card">
          <span>EXERCÍCIO DE DIREITOS</span>
          <h2>Fale com a Gruppu</h2>
          <p>
            Solicitações relacionadas a privacidade podem ser enviadas pelos canais oficiais da
            Gruppu ou por correspondência para o endereço informado nesta Política.
          </p>
        </section>

        <small className="legal-version">Última atualização: 4 de agosto de 2026.</small>
      </article>
    </main>
  );
}
