import type { Metadata } from "next";
import Link from "next/link";
import { blogArticles } from "@/lib/blog/articles";

export const metadata: Metadata = {
  title: "Blog Gruppu | Ideias para vender mais no iFood",
  description: "Conteúdos práticos sobre cardápio, vendas, gestão e crescimento para restaurantes no iFood.",
};

export default function Blog() {
  return (
    <main className="blog-shell">
      <header className="site-header blog-header">
        <Link className="brand" href="/" aria-label="Gruppu — início">
          GRUPPU<span className="brand-dot">.</span>
        </Link>
        <nav className="site-nav" aria-label="Navegação principal">
          <Link href="/">Análise ao vivo</Link>
          <span className="nav-active">Blog</span>
        </nav>
      </header>

      <section className="blog-hero">
        <p className="blog-kicker">CONTEÚDO GRUPPU / PARA QUEM QUER CRESCER</p>
        <h1>Como vender mais no iFood. <em>Sem depender de promoções.</em></h1>
        <p>
          Estratégias simples sobre cardápio, vendas e gestão no iFood — explicadas
          para você entender hoje e aplicar amanhã.
        </p>
      </section>

      <section className="featured-story" aria-labelledby="featured-title">
        <div className="featured-copy">
          <span className="article-tag">GUIA PRÁTICO · DESTAQUE</span>
          <h2 id="featured-title">Antes de investir mais, descubra onde sua loja está perdendo pedidos.</h2>
          <p>
            Mais visitas não resolvem uma página que não convence. O primeiro passo é
            olhar para quatro pontos: foto de capa, ordem do cardápio, força dos
            produtos principais e facilidade para montar o pedido.
          </p>
          <ul>
            <li>O cliente entende em 5 segundos o que sua loja vende?</li>
            <li>Seus melhores produtos aparecem antes dos menos importantes?</li>
            <li>Os adicionais ajudam a comprar ou só criam confusão?</li>
          </ul>
          <Link className="story-cta" href="/#cadastro">Quero analisar minha loja <span aria-hidden="true">↗</span></Link>
        </div>
        <div className="score-card" aria-hidden="true">
          <span>CHECK-UP DE LOJA</span>
          <strong>04</strong>
          <div><i /> Clareza</div>
          <div><i /> Conversão</div>
          <div><i /> Ticket médio</div>
          <div><i /> Recompra</div>
        </div>
      </section>

      <section className="article-section" aria-labelledby="articles-title">
        <div className="section-heading">
          <div>
            <span>NOVOS CONTEÚDOS</span>
            <h2 id="articles-title">Aprenda no seu ritmo.</h2>
          </div>
          <p>Leituras curtas, exemplos reais e decisões que melhoram o caixa.</p>
        </div>

        <div className="article-grid">
          {blogArticles.map((article) => (
            <article className="article-card" key={article.number}>
              <div className="article-meta">
                <span>{article.category}</span>
                <span>{article.time} de leitura</span>
              </div>
              <span className="article-number" aria-hidden="true">{article.number}</span>
              <h3>{article.title}</h3>
              <p>{article.excerpt}</p>
              <Link className="article-link" href={`/blog/${article.slug}`}>Ler artigo completo <span aria-hidden="true">→</span></Link>
            </article>
          ))}
        </div>
      </section>

      <section className="blog-cta">
        <div>
          <span>PRÓXIMA ANÁLISE · SEGUNDA ÀS 16H</span>
          <h2>Quer ver esses ajustes em lojas reais?</h2>
          <p>Participe gratuitamente e receba o link pelo grupo oficial.</p>
        </div>
        <Link href="/#cadastro">Entrar no grupo do WhatsApp <span aria-hidden="true">↗</span></Link>
      </section>

      <footer>
        <span>GRUPPU — GESTÃO ESTRATÉGICA IFOOD</span>
        <span><Link href="/">Análise ao vivo</Link> · @gruppu_</span>
      </footer>
    </main>
  );
}
