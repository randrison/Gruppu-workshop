import Home from "../page";

export default function CapturaPage() { return <Home />; }

