"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

function money(value: number) { return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 }); }

export default function CalculatorPage() {
  const [orders, setOrders] = useState(900);
  const [ticket, setTicket] = useState(42);
  const [margin, setMargin] = useState(22);
  const [growth, setGrowth] = useState(15);
  const result = useMemo(() => {
    const revenue = orders * ticket;
    const extra = revenue * (growth / 100);
    return { revenue, extra, profit: extra * (margin / 100), annual: extra * 12 };
  }, [orders, ticket, margin, growth]);

  return (
    <main className="calc-shell">
      <header className="calc-header"><Link className="crm-logo" href="/">GRUPPU<span>.</span></Link><nav><Link href="/calculadora/precificacao-ifood">Precificação</Link><Link href="/blog">Conteúdos</Link><Link href="/#cadastro">Análise gratuita</Link></nav></header>
      <section className="calc-hero"><div><span>FERRAMENTA GRATUITA PARA RESTAURANTES</span><h1>Quanto sua loja pode faturar <em>a mais no iFood?</em></h1><p>Faça uma projeção simples usando seus pedidos e ticket médio. Você verá faturamento, lucro adicional e potencial anual.</p></div><div className="calc-stamp"><strong>{growth}%</strong><span>meta usada na simulação</span></div></section>

      <nav className="calculator-switcher" aria-label="Escolha uma calculadora"><Link className="active" href="/calculadora">Potencial de crescimento</Link><Link href="/calculadora/precificacao-ifood">Preço ideal no iFood <span>NOVA</span></Link></nav>

      <section className="calculator-card">
        <div className="calc-inputs">
          <div className="calc-section-title"><span>PASSO 1</span><div><strong>Informe os números da sua loja</strong><small>Use a média dos últimos 30 dias.</small></div></div>
          <label>Quantos pedidos você recebe por mês? <input type="number" value={orders} onChange={(e) => setOrders(Number(e.target.value))} min="0" /></label>
          <label>Qual é o seu ticket médio? <div className="money-input"><span>R$</span><input type="number" value={ticket} onChange={(e) => setTicket(Number(e.target.value))} min="0" /></div></label>
          <label>Qual é sua margem líquida aproximada? <div className="money-input suffix"><input type="number" value={margin} onChange={(e) => setMargin(Number(e.target.value))} min="0" max="100" /><span>%</span></div><small className="field-help">Se não souber, use uma estimativa conservadora.</small></label>
          <label className="range-label"><span>Meta de crescimento <strong>{growth}%</strong></span><input type="range" value={growth} onChange={(e) => setGrowth(Number(e.target.value))} min="5" max="40" step="1" /></label>
        </div>
        <div className="calc-results">
          <div className="calc-section-title light"><span>RESULTADO</span><div><strong>Seu potencial estimado</strong><small>Os valores mudam conforme você preenche.</small></div></div>
          <div className="result-main"><span>FATURAMENTO EXTRA POR MÊS</span><strong>{money(result.extra)}</strong><small>considerando uma evolução de {growth}%</small></div>
          <div className="result-grid"><div><span>Faturamento atual</span><strong>{money(result.revenue)}</strong></div><div><span>Lucro extra/mês</span><strong>{money(result.profit)}</strong></div><div><span>Potencial em 12 meses</span><strong>{money(result.annual)}</strong></div></div>
          <Link href="/#cadastro">Receber um diagnóstico gratuito <span>↗</span></Link><p>Veja ao vivo quais ajustes podem aproximar sua loja desse resultado.</p>
        </div>
      </section>

      <section className="calc-explainer">
        <div><span>COMO CALCULAMOS</span><h2>Uma projeção simples, sem promessa mágica.</h2></div>
        <ol><li><b>1</b><div><strong>Faturamento atual</strong><p>Pedidos mensais multiplicados pelo ticket médio informado.</p></div></li><li><b>2</b><div><strong>Receita adicional</strong><p>Aplicamos a meta de crescimento escolhida sobre o faturamento atual.</p></div></li><li><b>3</b><div><strong>Lucro adicional</strong><p>Usamos a margem líquida informada para estimar quanto pode sobrar.</p></div></li></ol>
      </section>
      <section className="calc-next-tool"><div><span>PRÓXIMA FERRAMENTA</span><h2>Seu preço no iFood cobre todas as taxas?</h2><p>Calcule o preço recomendado considerando comissão, pagamento online, entrega e promoções.</p></div><Link href="/calculadora/precificacao-ifood">Abrir calculadora de precificação <span>→</span></Link></section>
      <footer><span>GRUPPU — GESTÃO ESTRATÉGICA IFOOD</span><span>Simulação educativa. Os resultados reais podem variar.</span></footer>
    </main>
  );
}
