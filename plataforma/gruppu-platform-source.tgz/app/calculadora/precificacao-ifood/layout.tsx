import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Calculadora iFood grátis: preço, taxas e lucro | Gruppu",
  description: "Use a calculadora de precificação iFood para descobrir quanto cobrar considerando comissão, taxa online, entrega, campanhas e margem de lucro.",
  keywords: [
    "calculadora iFood",
    "calculadora de precificação iFood",
    "como calcular preço no iFood",
    "taxa iFood",
    "comissão iFood",
    "preço de venda delivery",
  ],
  robots: { index: true, follow: true },
  openGraph: {
    title: "Calculadora iFood grátis: calcule preço, taxas e lucro",
    description: "Simule o preço de venda no iFood considerando comissão, pagamento online, entrega e campanhas.",
    type: "website",
  },
};

export default function PricingLayout({ children }: { children: React.ReactNode }) { return children; }
