"use client";

import { useMemo, useState } from "react";
import Link from "next/link";

function money(value: number) { return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL", minimumFractionDigits: 2 }); }

type PromotionType = "none" | "smart" | "coupon10" | "coupon20" | "freeDelivery" | "customFixed" | "percent";

const faqItems = [
  {
    question: "Como calcular o preço de venda no iFood?",
    answer: "Informe separadamente o custo do produto (CMV) e quanto deseja lucrar em cada venda. Depois, selecione as taxas, a entrega e o investimento em campanhas. A calculadora encontra o preço necessário para que o lucro desejado continue sobrando depois desses descontos.",
  },
  {
    question: "Quanto o iFood cobra do restaurante?",
    answer: "As páginas oficiais do iFood apresentam como referência comissão de 12% no Plano Básico e 23% no Plano Entrega, além de 3,2% para pagamentos processados no aplicativo. As condições podem variar por contrato, região e modalidade.",
  },
  {
    question: "Posso vender mais caro no iFood do que no balcão?",
    answer: "O preço no aplicativo pode precisar ser diferente para absorver custos específicos do canal, mas ele também deve ser competitivo e coerente com a percepção de valor do cliente. Simule primeiro e valide o resultado no mercado.",
  },
  {
    question: "A calculadora inclui comissão, pagamento online e promoções?",
    answer: "Sim. Você escolhe o plano, ativa ou desativa o pagamento online, informa quanto a loja paga de entrega e escolhe se a campanha custa um valor fixo por pedido ou um percentual sobre a venda.",
  },
  {
    question: "Como informar Campanha Inteligente, desconto e iFood Anúncios?",
    answer: "Para Campanha Inteligente ou cupom, use o custo que a sua loja realmente banca por pedido. Para desconto em item, você também pode usar a opção percentual. O iFood Anúncios é um investimento por visita ao cardápio e deve ser analisado separadamente, não como desconto obrigatório em toda venda.",
  },
  {
    question: "Como saber se estou tendo lucro no iFood?",
    answer: "Compare o valor líquido estimado com o custo completo do pedido: ingredientes, embalagem, impostos, mão de obra e despesas da operação. Faturamento alto não garante lucro quando esses custos não estão mapeados.",
  },
  {
    question: "Esta calculadora substitui as taxas do meu contrato?",
    answer: "Não. Ela é uma ferramenta educativa baseada em referências públicas. Para tomar a decisão final, confira as taxas, mensalidades e regras vigentes no Portal do Parceiro e no contrato da sua loja.",
  },
];

export default function PricingPage() {
  const [productCost, setProductCost] = useState(5);
  const [desiredProfit, setDesiredProfit] = useState(10);
  const [plan, setPlan] = useState<"basic" | "delivery">("basic");
  const [onlinePayment, setOnlinePayment] = useState(true);
  const [includeTax, setIncludeTax] = useState(false);
  const [taxRate, setTaxRate] = useState(4);
  const [deliveryCost, setDeliveryCost] = useState(0);
  const [promotion, setPromotion] = useState<PromotionType>("none");
  const [campaignValue, setCampaignValue] = useState(0);
  const rate = plan === "basic" ? 12 : 23;
  const paymentRate = onlinePayment ? 3.2 : 0;
  const appliedTaxRate = includeTax ? Math.min(Math.max(taxRate, 0), 30) : 0;
  const result = useMemo(() => {
    const safeCost = Math.max(productCost, 0);
    const safeProfit = Math.max(desiredProfit, 0);
    const safeDelivery = Math.max(deliveryCost, 0);
    const campaignPercent = promotion === "percent" ? Math.min(Math.max(campaignValue, 0), 50) : 0;
    const presetCampaignValue = promotion === "smart" ? 5 : promotion === "coupon10" ? 10 : promotion === "coupon20" ? 20 : promotion === "freeDelivery" ? 9.99 : 0;
    const campaignFixed = promotion === "customFixed" ? Math.max(campaignValue, 0) : presetCampaignValue;
    const totalRate = Math.min(rate + paymentRate + campaignPercent + appliedTaxRate, 90);
    const recommended = (safeCost + safeProfit + safeDelivery + campaignFixed) / (1 - totalRate / 100);
    const commission = recommended * rate / 100;
    const payment = recommended * paymentRate / 100;
    const tax = recommended * appliedTaxRate / 100;
    const campaign = promotion === "percent" ? recommended * campaignPercent / 100 : campaignFixed;
    const profit = recommended - commission - payment - tax - campaign - safeDelivery - safeCost;

    return { totalRate, recommended, commission, payment, tax, campaign, profit, campaignPercent, safeCost, safeDelivery };
  }, [productCost, desiredProfit, deliveryCost, rate, paymentRate, appliedTaxRate, promotion, campaignValue]);

  const promotionLabel = promotion === "smart"
    ? "Campanha Inteligente"
    : promotion === "coupon10"
      ? "Cupom de R$ 10"
      : promotion === "coupon20"
        ? "Cupom de R$ 20"
        : promotion === "freeDelivery"
          ? "Campanha com entrega grátis"
          : promotion === "customFixed"
            ? "Outro investimento por pedido"
            : promotion === "percent"
              ? `Desconto em item (${result.campaignPercent.toFixed(1)}%)`
              : "Nenhuma promoção";

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqItems.map((item) => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: { "@type": "Answer", text: item.answer },
    })),
  };

  return (
    <main className="calc-shell pricing-shell">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      <header className="calc-header"><Link className="crm-logo" href="/">GRUPPU<span>.</span></Link><nav><Link href="/calculadora">Crescimento</Link><Link href="/blog">Conteúdos</Link><Link href="/captura?origem=calculadora-precificacao#cadastro">Análise gratuita</Link></nav></header>
      <section className="calc-hero pricing-hero"><div><span>CALCULADORA IFOOD GRÁTIS PARA RESTAURANTES</span><h1>Calculadora de precificação iFood: <em>calcule o preço sem perder margem.</em></h1><p>Você pode vender muito no iFood e ainda perder dinheiro. O erro mais comum é somar as taxas ao custo, porque o iFood desconta a comissão sobre o preço final da venda. Informe seu CMV, promoções e lucro desejado para descobrir quanto realmente precisa cobrar.</p></div><div className="calc-stamp"><strong>{result.totalRate.toFixed(1)}%</strong><span>taxas percentuais consideradas nesta simulação</span></div></section>
      <nav className="calculator-switcher" aria-label="Escolha uma calculadora"><Link href="/calculadora">Potencial de crescimento</Link><Link className="active" href="/calculadora/precificacao-ifood">Preço ideal no iFood</Link></nav>

      <section className="calculator-card pricing-card">
        <div className="calc-inputs">
          <div className="calc-section-title"><span>DADOS</span><div><strong>Monte o cenário da sua venda</strong><small>Informe seus custos primeiro e escolha o lucro no final.</small></div></div>
          <label>Custo do produto (CMV)
            <div className="money-input"><span>R$</span><input type="number" value={productCost} onChange={(e) => setProductCost(Number(e.target.value))} min="0" step="0.5" /></div>
            <span className="field-help">Ingredientes, embalagem e perdas para produzir uma unidade.</span>
          </label>
          <label>Plano contratado no iFood <select value={plan} onChange={(e) => setPlan(e.target.value as "basic" | "delivery")}><option value="basic">Plano Básico — 12% de comissão</option><option value="delivery">Plano Entrega — 23% de comissão</option></select></label>
          <label className="toggle-line"><input type="checkbox" checked={onlinePayment} onChange={(e) => setOnlinePayment(e.target.checked)} /><span>Pagamento feito pelo iFood</span><small>Inclui a taxa padrão de 3,2%</small></label>
          <label className={`toggle-line advanced-toggle ${includeTax ? "active" : ""}`}><input type="checkbox" checked={includeTax} onChange={(e) => setIncludeTax(e.target.checked)} /><span>Incluir imposto no cálculo</span><small>Opcional: use a alíquota efetiva informada pelo seu contador</small></label>
          {includeTax && <div className="advanced-cost-panel">
            <label>Imposto sobre a venda
              <div className="money-input suffix"><input type="number" value={taxRate} onChange={(e) => setTaxRate(Number(e.target.value))} min="0" max="30" step="0.1" /><span>%</span></div>
              <span className="field-help">Informe a porcentagem efetiva de imposto da sua empresa. Se tiver dúvida, confirme com seu contador.</span>
            </label>
          </div>}
          <label>Promoções do iFood
            <select value={promotion} onChange={(e) => setPromotion(e.target.value as PromotionType)}>
              <option value="none">Nenhuma promoção</option>
              <option value="smart">Campanha Inteligente — R$ 5 por pedido</option>
              <option value="coupon10">Cupom de R$ 10 bancado pela loja</option>
              <option value="coupon20">Cupom de R$ 20 bancado pela loja</option>
              <option value="freeDelivery">Campanha com entrega grátis — até R$ 9,99</option>
              <option value="percent">Desconto em item — informar percentual</option>
              <option value="customFixed">Outro valor por pedido — informar em reais</option>
            </select>
            <span className="field-help">Escolha a promoção. O custo conhecido entra automaticamente na conta.</span>
          </label>
          {promotion !== "none" && promotion !== "customFixed" && promotion !== "percent" && <p className="promotion-preview"><span>Valor usado na simulação</span><strong>{money(result.campaign)} por pedido</strong><small>Valor de referência. Se o Portal mostrar outro custo para sua loja, escolha “Outro valor por pedido”.</small></p>}
          <div className="calc-input-pair operational-costs">
            <label>Entrega paga pela loja
              <div className="money-input"><span>R$</span><input type="number" value={deliveryCost} onChange={(e) => setDeliveryCost(Number(e.target.value))} min="0" step="0.5" /></div>
              <span className="field-help">Se não existe custo adicional por pedido, deixe zero.</span>
            </label>
            {(promotion === "customFixed" || promotion === "percent") && <label>{promotion === "customFixed" ? "Investimento por pedido" : "Percentual bancado pela loja"}
              <div className={`money-input ${promotion === "percent" ? "suffix" : ""}`}>
                {promotion === "customFixed" && <span>R$</span>}
                <input type="number" value={campaignValue} onChange={(e) => setCampaignValue(Number(e.target.value))} min="0" max={promotion === "percent" ? 50 : undefined} step="0.5" />
                {promotion === "percent" && <span>%</span>}
              </div>
              <span className="field-help">Confira o custo efetivo no Portal do Parceiro.</span>
            </label>}
          </div>
          <label className="profit-goal-field">Quanto você quer lucrar nesta venda?
            <div className="money-input"><span>R$</span><input type="number" value={desiredProfit} onChange={(e) => setDesiredProfit(Number(e.target.value))} min="0" step="0.5" /></div>
            <span className="field-help">Digite o valor que deve sobrar depois do CMV, taxas, entrega e promoção.</span>
          </label>
          <p className="rate-notice"><strong>Anúncios ficam fora desta conta.</strong> Eles são um investimento por visita ao cardápio, e não um desconto obrigatório em cada pedido. Taxas e campanhas podem variar; confirme os valores no Portal do Parceiro.</p>
        </div>
        <div className="calc-results pricing-results">
          <div className="calc-section-title light"><span>PREÇO</span><div><strong>Preço recomendado no app</strong><small>Para pagar os custos e preservar o lucro informado.</small></div></div>
          <div className="result-main"><span>PREÇO DE VENDA SUGERIDO</span><strong>{money(result.recommended)}</strong><small>lucro estimado depois dos custos informados: {money(result.profit)}</small></div>
          <div className="fee-breakdown">
            <div><span>Comissão do plano ({rate}%)</span><strong>- {money(result.commission)}</strong></div>
            <div><span>Pagamento online ({paymentRate.toFixed(1)}%)</span><strong>- {money(result.payment)}</strong></div>
            {includeTax && <div><span>Imposto informado ({appliedTaxRate.toFixed(1)}%)</span><strong>- {money(result.tax)}</strong></div>}
            {promotion !== "none" && <div><span>{promotionLabel}</span><strong>- {money(result.campaign)}</strong></div>}
            {result.safeDelivery > 0 && <div><span>Entrega paga pela loja</span><strong>- {money(result.safeDelivery)}</strong></div>}
            <div><span>Custo do produto (CMV)</span><strong>- {money(result.safeCost)}</strong></div>
            <div className="fee-total"><span>Lucro que sobra nesta venda</span><strong>{money(result.profit)}</strong></div>
          </div>
          <Link className="pricing-result-cta" href="/captura?origem=calculadora-precificacao#cadastro">
            <span className="pricing-cta-copy"><strong>Quero analisar minha loja grátis</strong><small>Receber uma análise ao vivo da Gruppu</small></span>
            <span className="pricing-cta-arrow" aria-hidden="true">↗</span>
          </Link>
        </div>
      </section>
      <p className="calculator-privacy"><strong>Privacidade:</strong> os números informados na calculadora não são armazenados. A Gruppu só recebe dados quando você decide solicitar uma análise gratuita e preenche o formulário.</p>

      <section className="ifood-rates-section"><div className="rates-heading"><span>TAXAS E COMISSÕES</span><h2>Quanto o iFood cobra do restaurante?</h2><p>Use esta tabela como referência para comparar os planos. Os valores foram consultados em agosto de 2026, mas o contrato da sua loja sempre prevalece.</p></div><div className="rates-table"><div className="rates-row head"><span>Plano</span><span>Comissão</span><span>Pagamento online</span><span>Mensalidade*</span></div><div className="rates-row"><strong>Básico</strong><span>12%</span><span>3,2%</span><span>R$ 110/mês</span></div><div className="rates-row"><strong>Entrega</strong><span>23%</span><span>3,2%</span><span>R$ 150/mês</span></div></div><small>*Mensalidade padrão para faturamento acima de R$ 1.800/mês, conforme a página oficial dos planos. Taxas e condições podem variar.</small><div className="plan-comparison"><article><span>PLANO BÁSICO</span><h3>Mais controle da entrega</h3><p>A loja cuida da própria logística. A comissão de referência é menor, mas você precisa incluir motoboy, rota e possíveis perdas no custo do pedido.</p></article><article><span>PLANO ENTREGA</span><h3>Logística pelo aplicativo</h3><p>A comissão de referência é maior porque a entrega faz parte do plano. Compare esse percentual com o custo real da sua operação logística.</p></article></div></section>

      <section className="calc-explainer pricing-explainer"><div><span>COMO CALCULAR</span><h2>Como calcular o preço de venda no iFood sem esconder prejuízo.</h2><p className="section-intro">A calculadora separa o dinheiro que paga o produto do dinheiro que realmente vira lucro.</p></div><ol><li><b>1</b><div><strong>Informe o CMV do produto</strong><p>Some ingredientes, embalagem e perdas para saber quanto custa produzir uma unidade.</p></div></li><li><b>2</b><div><strong>Escolha o lucro desejado</strong><p>Digite quanto você quer que sobre nesta venda depois de todos os descontos calculados.</p></div></li><li><b>3</b><div><strong>Inclua as taxas do canal</strong><p>Considere comissão, pagamento online, entrega e somente a parte da campanha bancada pela loja.</p></div></li><li><b>4</b><div><strong>Valide o preço no mercado</strong><p>Compare concorrentes, posicionamento e percepção de valor antes de publicar no cardápio.</p></div></li></ol></section>

      <section className="pricing-guide-section"><div className="rates-heading"><span>GUIA RÁPIDO</span><h2>O que informar na calculadora de precificação iFood</h2><p>Cada campo responde a uma parte diferente do preço. Preencher com dados reais deixa a simulação mais próxima da sua operação.</p></div><div className="pricing-guide-grid"><article><strong>Custo do produto (CMV)</strong><p>É o custo de ingredientes, embalagem e perdas para produzir uma unidade. Ele não é o seu lucro.</p></article><article><strong>Lucro desejado</strong><p>É o valor em reais que você quer que sobre depois do CMV, das taxas e dos demais custos informados.</p></article><article><strong>Plano e pagamento</strong><p>Escolha seu plano e indique se o pedido é pago no app para aplicar os percentuais de referência.</p></article><article><strong>Campanhas e entrega</strong><p>Informe somente o valor que sua loja realmente assume naquele pedido, em reais ou percentual.</p></article></div></section>

      <section className="pricing-faq-section"><div className="rates-heading"><span>DÚVIDAS FREQUENTES</span><h2>Perguntas sobre preço, taxas e lucro no iFood</h2><p>Respostas diretas para donos de restaurantes, hamburguerias, pizzarias, marmitarias e outras operações de delivery.</p></div><div className="pricing-faq-list">{faqItems.map((item) => <details key={item.question}><summary>{item.question}<span>+</span></summary><p>{item.answer}</p></details>)}</div></section>

      <section className="pricing-lead-cta"><div><span>ANÁLISE GRATUITA</span><h2>A conta fechou. Agora vamos analisar sua loja?</h2><p>Cadastre-se para participar da análise ao vivo da Gruppu. Vamos olhar cardápio, preço, margem e oportunidades de venda sem depender apenas de promoções.</p><small>Ao avançar, seu cadastro será marcado com a origem “Calculadora de Precificação” para aparecer corretamente no painel.</small></div><Link href="/captura?origem=calculadora-precificacao#cadastro"><span>Quero analisar minha loja grátis</span><span className="pricing-cta-arrow" aria-hidden="true">↗</span></Link></section>
      <footer><span>GRUPPU — GESTÃO ESTRATÉGICA IFOOD</span><span>Ferramenta educativa; confirme as taxas no seu contrato.</span></footer>
    </main>
  );
}
