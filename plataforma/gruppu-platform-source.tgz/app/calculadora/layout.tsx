import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Calculadoras gratuitas para iFood | Gruppu",
  description: "Ferramentas gratuitas para calcular crescimento, preço de venda, taxas e margem no iFood.",
};

export default function CalculatorLayout({ children }: { children: React.ReactNode }) { return children; }
