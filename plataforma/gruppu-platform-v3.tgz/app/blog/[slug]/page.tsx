import type { Metadata } from "next";
import Link from "next/link";
import { blogArticles, getBlogArticle } from "../../../lib/blog/articles";

export function generateStaticParams() {
  return blogArticles.map((article) => ({ slug: article.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const article = getBlogArticle(slug);
  if (!article) return { title: "Conteúdo não encontrado | Gruppu" };
  return {
    title: `${article.title} | Gruppu`,
    description: article.description,
    alternates: { canonical: `https://gruppu.com.br/blog/${article.slug}` },
  };
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = getBlogArticle(slug);

  if (!article) {
    return <main className="article-page"><section className="article-not-found"><h1>Conteúdo não encontrado.</h1><Link href="/blog">Voltar ao blog</Link></section></main>;
  }

  return (
    <main className="article-page">
      <header className="site-header blog-header">
        <Link className="brand" href="/" aria-label="Gruppu — início">GRUPPU<span className="brand-dot">.</span></Link>
        <nav className="site-nav" aria-label="Navegação principal"><Link href="/blog">← Voltar ao blog</Link></nav>
      </header>

      <article className="article-reading">
        <header className="article-reading-hero">
          <div className="article-reading-meta"><span>{article.category}</span><span>{article.time} de leitura</span></div>
          <span className="article-reading-number" aria-hidden="true">{article.number}</span>
          <h1>{article.title}</h1>
          <p>{article.intro}</p>
        </header>

        <div className="article-reading-body">
          {article.sections.map((section) => (
            <section key={section.title}>
              <h2>{section.title}</h2>
              {section.paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
              {section.bullets && <ul>{section.bullets.map((bullet) => <li key={bullet}>{bullet}</li>)}</ul>}
            </section>
          ))}
        </div>

        <aside className="article-reading-cta">
          <div><span>ANÁLISE GRATUITA · SEGUNDA ÀS 16H</span><h2>Quer descobrir onde sua loja pode vender mais?</h2><p>Cadastre-se para participar da análise de lojas ao vivo da Gruppu.</p></div>
          <Link href="/#cadastro">Quero analisar minha loja <span aria-hidden="true">→</span></Link>
        </aside>
      </article>

      <footer><span>GRUPPU — GESTÃO ESTRATÉGICA IFOOD</span><span><Link href="/blog">Mais conteúdos</Link> · @gruppu_</span></footer>
    </main>
  );
}
