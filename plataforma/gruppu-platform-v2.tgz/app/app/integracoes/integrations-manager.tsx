"use client";

import { useEffect, useState } from "react";
import { integrationCatalog } from "../../../lib/integrations/catalog";

type StatusMap = Record<string, { configured: boolean; configuredCount: number; total: number }>;

export default function IntegrationsManager() {
  const [statuses, setStatuses] = useState<StatusMap>({});
  const [selected, setSelected] = useState<(typeof integrationCatalog)[number] | null>(null);
  const [loading, setLoading] = useState(false);

  async function refresh() {
    setLoading(true);
    const response = await fetch("/api/integrations/status", { cache: "no-store" });
    if (response.ok) setStatuses(await response.json() as StatusMap);
    setLoading(false);
  }

  useEffect(() => {
    let active = true;
    fetch("/api/integrations/status", { cache: "no-store" }).then((response) => response.ok ? response.json() : {}).then((data: StatusMap) => { if (active) setStatuses(data); });
    return () => { active = false; };
  }, []);

  const connected = integrationCatalog.filter((item) => item.id === "sheets" || statuses[item.id]?.configured).length;

  return <>
    <section className="crm-page-intro integration-intro"><div><p>Clique em uma conexão para ver o que falta. As chaves ficam somente nas variáveis protegidas da hospedagem e nunca aparecem no navegador.</p></div><strong>{connected}/{integrationCatalog.length}</strong><span>prontas para uso</span></section>
    <section className="integration-grid">{integrationCatalog.map((integration) => {
      const status = integration.id === "sheets" ? { configured: true, configuredCount: 0, total: 0 } : statuses[integration.id];
      return <button type="button" className="crm-panel integration-card integration-card-button" key={integration.id} onClick={() => setSelected(integration)}><div className="integration-card-head"><span>{integration.category}</span><b className={`integration-status ${status?.configured ? "status-ready" : "status-needs-key"}`}>{status?.configured ? "Pronta" : "Configurar"}</b></div><h2>{integration.name}</h2><p>{integration.purpose}</p><small>{integration.env.length === 0 ? "Clique para usar" : `${status?.configuredCount ?? 0}/${integration.env.length} variáveis configuradas`}</small></button>;
    })}</section>
    <section className="crm-panel security-note"><div><span>CONEXÃO SEGURA</span><h2>As credenciais nunca são gravadas nesta tela.</h2></div><button className="crm-secondary-button" onClick={refresh} disabled={loading}>{loading ? "Verificando…" : "Atualizar status"}</button></section>
    {selected && <div className="crm-modal-backdrop" role="presentation" onMouseDown={() => setSelected(null)}><section className="crm-modal" role="dialog" aria-modal="true" aria-labelledby="integration-title" onMouseDown={(event) => event.stopPropagation()}><button className="crm-modal-close" onClick={() => setSelected(null)} aria-label="Fechar">×</button><span>{selected.category}</span><h2 id="integration-title">Conectar {selected.name}</h2><p>{selected.purpose}</p>{selected.id === "sheets" ? <div className="integration-instructions"><strong>Já funciona agora</strong><p>Use “Exportar clientes” ou “Exportar leads” para gerar um CSV que abre no Excel e no Google Sheets. A sincronização automática exigirá uma conta Google autorizada.</p><a href="/app/clientes">Ir para clientes →</a></div> : <div className="integration-instructions"><strong>Variáveis necessárias na Vercel</strong><ul>{selected.env.map((variable) => <li key={variable}><code>{variable}</code><b>{process.env.NODE_ENV === "development" ? "servidor" : "protegida"}</b></li>)}</ul><p>Depois de preencher essas variáveis no ambiente seguro, volte aqui e clique em “Atualizar status”.</p>{selected.id === "whatsapp" && <small>O nome “Beirute” ainda precisa ser confirmado como provedor, plataforma ou nome da instância. O conector ficou genérico para não prender o sistema à API errada.</small>}</div>}<button className="crm-secondary-button" onClick={() => setSelected(null)}>Entendi</button></section></div>}
  </>;
}
