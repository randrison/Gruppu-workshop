"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { readLocalLeads, subscribeToLocalLeads } from "../../../lib/crm/local-store";
import type { CrmLead } from "../../../lib/crm/types";
import { recordAuditLog } from "../../../lib/crm/audit-store";
import ExportButton from "../_components/export-button";

type Campaign = {
  id: string;
  segment: string;
  subject: string;
  body: string;
  recipientIds: string[];
  status: "Rascunho" | "Agendado";
  scheduledAt?: string;
  createdAt: string;
};

type ContactList = { id: string; name: string; leadIds: string[]; createdAt: string };
type PanelTab = "Criar campanha" | "Histórico" | "Listas";

const campaignKey = "gruppu.crm.email-campaigns.v3";
const listsKey = "gruppu.crm.email-lists.v1";
const segments = ["Todos com consentimento", "Novos", "Qualificados", "Últimos 7 dias", "Não compareceram"];

function matchesSegment(lead: CrmLead, segment: string, referenceTime: number) {
  if (!lead.consentEmail) return false;
  if (segment === "Novos") return lead.status === "Novo";
  if (segment === "Qualificados") return lead.status === "Qualificado";
  if (segment === "Últimos 7 dias") return lead.createdAt ? referenceTime - new Date(lead.createdAt).getTime() <= 7 * 86400000 : false;
  if (segment === "Não compareceram") return lead.status === "Não compareceu";
  return true;
}

export default function EmailMarketingPanel() {
  const [leads, setLeads] = useState<CrmLead[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [lists, setLists] = useState<ContactList[]>([]);
  const [tab, setTab] = useState<PanelTab>("Criar campanha");
  const [segment, setSegment] = useState(segments[0]);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [activeListId, setActiveListId] = useState("");
  const [listName, setListName] = useState("");
  const [search, setSearch] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("16:00");
  const [error, setError] = useState("");
  const [referenceTime] = useState(() => Date.now());

  useEffect(() => {
    const refresh = () => setLeads(readLocalLeads());
    const savedCampaigns = localStorage.getItem(campaignKey);
    const savedLists = localStorage.getItem(listsKey);
    queueMicrotask(() => {
      const currentLeads = readLocalLeads();
      setLeads(currentLeads);
      setSelectedIds(currentLeads.filter((lead) => matchesSegment(lead, segments[0], referenceTime)).map((lead) => lead.id));
      if (savedCampaigns) setCampaigns(JSON.parse(savedCampaigns) as Campaign[]);
      if (savedLists) setLists(JSON.parse(savedLists) as ContactList[]);
    });
    return subscribeToLocalLeads(refresh);
  }, [referenceTime]);

  const eligibleLeads = useMemo(() => leads.filter((lead) => lead.consentEmail), [leads]);
  const selectedRecipients = useMemo(() => eligibleLeads.filter((lead) => selectedIds.includes(lead.id)), [eligibleLeads, selectedIds]);
  const visibleLeads = useMemo(() => {
    const normalized = search.toLowerCase().trim();
    if (!normalized) return eligibleLeads;
    return eligibleLeads.filter((lead) => `${lead.name} ${lead.email} ${lead.source} ${lead.goal}`.toLowerCase().includes(normalized));
  }, [eligibleLeads, search]);

  function persistCampaigns(next: Campaign[]) {
    setCampaigns(next);
    localStorage.setItem(campaignKey, JSON.stringify(next));
  }

  function persistLists(next: ContactList[]) {
    setLists(next);
    localStorage.setItem(listsKey, JSON.stringify(next));
  }

  function chooseSegment(nextSegment: string) {
    setSegment(nextSegment);
    setActiveListId("");
    setSelectedIds(leads.filter((lead) => matchesSegment(lead, nextSegment, referenceTime)).map((lead) => lead.id));
  }

  function chooseList(list: ContactList) {
    setActiveListId(list.id);
    setListName(list.name);
    setSelectedIds(list.leadIds.filter((id) => eligibleLeads.some((lead) => lead.id === id)));
    setTab("Criar campanha");
  }

  function toggleRecipient(id: string) {
    setSelectedIds((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  }

  function saveList() {
    const name = listName.trim();
    if (!name) { setError("Digite um nome para salvar esta lista."); return; }
    if (selectedIds.length === 0) { setError("Escolha pelo menos uma pessoa para a lista."); return; }
    const existing = lists.find((list) => list.id === activeListId);
    const item: ContactList = existing
      ? { ...existing, name, leadIds: selectedIds }
      : { id: crypto.randomUUID(), name, leadIds: selectedIds, createdAt: new Date().toISOString() };
    const next = existing ? lists.map((list) => list.id === item.id ? item : list) : [item, ...lists];
    persistLists(next);
    setActiveListId(item.id);
    setError("");
    recordAuditLog({ action: existing ? "Lista de e-mail atualizada" : "Lista de e-mail criada", entity: item.name, details: `${item.leadIds.length} contatos` });
  }

  function removeList(list: ContactList) {
    if (!confirm(`Excluir a lista “${list.name}”?`)) return;
    persistLists(lists.filter((item) => item.id !== list.id));
    if (activeListId === list.id) { setActiveListId(""); setListName(""); }
    recordAuditLog({ action: "Lista de e-mail excluída", entity: list.name, details: `${list.leadIds.length} contatos` });
  }

  function submitCampaign(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const submitter = (event.nativeEvent as SubmitEvent).submitter as HTMLButtonElement | null;
    const status: Campaign["status"] = submitter?.dataset.intent === "schedule" ? "Agendado" : "Rascunho";
    if (selectedIds.length === 0) { setError("Escolha pelo menos uma pessoa para receber o e-mail."); return; }
    if (status === "Agendado" && (!scheduleDate || !scheduleTime)) { setError("Escolha a data e o horário do envio."); return; }
    const campaign: Campaign = {
      id: crypto.randomUUID(),
      segment: activeListId ? lists.find((list) => list.id === activeListId)?.name || "Lista personalizada" : segment,
      subject,
      body,
      recipientIds: selectedIds,
      status,
      scheduledAt: status === "Agendado" ? `${scheduleDate}T${scheduleTime}` : undefined,
      createdAt: new Date().toISOString(),
    };
    persistCampaigns([campaign, ...campaigns]);
    recordAuditLog({ action: status === "Agendado" ? "E-mail programado" : "Campanha de e-mail salva", entity: subject, details: `${selectedIds.length} destinatários` });
    setSubject(""); setBody(""); setScheduleDate(""); setError(""); setTab("Histórico");
  }

  function removeCampaign(campaign: Campaign) {
    persistCampaigns(campaigns.filter((item) => item.id !== campaign.id));
    recordAuditLog({ action: "Campanha de e-mail excluída", entity: campaign.subject, details: campaign.status });
  }

  return (
    <div className="email-center">
      <nav className="email-tabs" aria-label="Áreas do e-mail marketing">
        {(["Criar campanha", "Histórico", "Listas"] as PanelTab[]).map((item) => <button key={item} className={tab === item ? "active" : ""} onClick={() => setTab(item)}>{item}{item === "Histórico" && <b>{campaigns.length}</b>}{item === "Listas" && <b>{lists.length}</b>}</button>)}
      </nav>

      {tab === "Criar campanha" && <form className="email-campaign-composer" onSubmit={submitCampaign}>
        <section className="crm-panel campaign-editor">
          <div className="crm-panel-head"><div><span>NOVA CAMPANHA</span><h2>Conteúdo e programação</h2></div><div className="campaign-audience-total"><strong>{selectedRecipients.length}</strong><span>destinatários selecionados</span></div></div>
          <div className="campaign-fields">
            <label>Público inicial<select value={segment} onChange={(event) => chooseSegment(event.target.value)}>{segments.map((item) => <option key={item}>{item}</option>)}</select></label>
            <div className="campaign-schedule-grid"><label>Data do envio<input type="date" value={scheduleDate} onChange={(event) => setScheduleDate(event.target.value)} /></label><label>Horário<input type="time" value={scheduleTime} onChange={(event) => setScheduleTime(event.target.value)} /></label></div>
            <label>Assunto<input value={subject} onChange={(event) => setSubject(event.target.value)} placeholder="Ex.: Sua análise ao vivo começa hoje às 16h" required /></label>
            <label>Mensagem<textarea value={body} onChange={(event) => setBody(event.target.value)} placeholder="Olá, {{nome}}..." required /></label>
            <small>Use <code>{"{{nome}}"}</code> para personalizar. Apenas contatos que autorizaram e-mail podem ser selecionados.</small>
            {error && <p className="field-error">{error}</p>}
            <div className="campaign-actions"><button type="submit" data-intent="draft">Salvar rascunho</button><button type="submit" data-intent="schedule" className="schedule-button">Programar e-mail</button></div>
            <button type="button" className="campaign-send-disabled" disabled>Enviar agora com Resend — aguardando conexão segura</button>
          </div>
        </section>

        <aside className="crm-panel recipient-manager">
          <div className="crm-panel-head"><div><span>LISTA DE ENVIO</span><h2>Escolha quem recebe</h2></div><ExportButton rows={selectedRecipients as unknown as Record<string, unknown>[]} fileName="destinatarios-email-gruppu.csv" label="Exportar" columns={[{ key: "name", label: "Nome" }, { key: "email", label: "E-mail" }, { key: "phone", label: "Telefone" }, { key: "status", label: "Etapa" }, { key: "source", label: "Origem" }, { key: "goal", label: "Interesse" }]} /></div>
          <div className="recipient-tools"><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Buscar nome, e-mail ou origem" /><div><button type="button" onClick={() => setSelectedIds(eligibleLeads.map((lead) => lead.id))}>Selecionar todos</button><button type="button" onClick={() => setSelectedIds([])}>Limpar</button></div></div>
          <div className="recipient-list">
            {visibleLeads.length === 0 ? <div className="empty-state">Nenhum contato com autorização para e-mail.</div> : visibleLeads.map((lead) => <label key={lead.id}><input type="checkbox" checked={selectedIds.includes(lead.id)} onChange={() => toggleRecipient(lead.id)} /><span className="lead-avatar">{lead.initials}</span><span><strong>{lead.name}</strong><small>{lead.email} · {lead.status}</small></span><b>{lead.source}</b></label>)}
          </div>
          <div className="save-list-bar"><input value={listName} onChange={(event) => setListName(event.target.value)} placeholder="Nome da lista, ex.: Live de agosto" /><button type="button" onClick={saveList}>{activeListId ? "Atualizar lista" : "Salvar como lista"}</button></div>
        </aside>
      </form>}

      {tab === "Histórico" && <section className="crm-panel campaign-history"><div className="crm-panel-head"><div><span>HISTÓRICO E PROGRAMAÇÃO</span><h2>Campanhas preparadas</h2></div></div>{campaigns.length === 0 ? <div className="empty-state">Nenhuma campanha salva ou programada.</div> : <div className="campaign-history-list">{campaigns.map((campaign) => <article key={campaign.id}><span className={`campaign-status ${campaign.status.toLowerCase()}`}>{campaign.status}</span><div><strong>{campaign.subject}</strong><p>{campaign.segment} · {campaign.recipientIds.length} destinatários</p><small>{campaign.scheduledAt ? `Programado para ${new Date(campaign.scheduledAt).toLocaleString("pt-BR")}` : `Criado em ${new Date(campaign.createdAt).toLocaleString("pt-BR")}`}</small></div><button onClick={() => removeCampaign(campaign)}>Excluir</button></article>)}</div>}</section>}

      {tab === "Listas" && <section className="crm-panel saved-lists-panel"><div className="crm-panel-head"><div><span>SEGMENTOS PERSONALIZADOS</span><h2>Listas salvas</h2></div><button onClick={() => { setActiveListId(""); setListName(""); setSelectedIds([]); setTab("Criar campanha"); }}>+ Criar nova lista</button></div>{lists.length === 0 ? <div className="empty-state">Nenhuma lista personalizada. Selecione contatos em “Criar campanha” e salve a seleção.</div> : <div className="saved-list-grid">{lists.map((list) => <article key={list.id}><span>{list.leadIds.length}</span><div><strong>{list.name}</strong><small>Criada em {new Date(list.createdAt).toLocaleDateString("pt-BR")}</small></div><button onClick={() => chooseList(list)}>Abrir e editar</button><button className="danger" onClick={() => removeList(list)}>Excluir</button></article>)}</div>}</section>}
    </div>
  );
}
