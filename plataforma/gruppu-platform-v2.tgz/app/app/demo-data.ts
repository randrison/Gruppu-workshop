import type { CrmLead, LeadStatus } from "../../lib/crm/types";

export type DemoLead = CrmLead;
export type { LeadStatus };

export type CrmClient = {
  id: string;
  company: string;
  contact: string;
  email: string;
  phone: string;
  plan: string;
  billingCycle: "Mensal" | "Trimestral" | "Semestral" | "Anual";
  monthly: number;
  totalPaid: number;
  start: string;
  status: string;
  result: string;
};

export const demoLeads: DemoLead[] = [];

export const funnel = [
  { label: "Cadastrados", value: 0, percent: 0 },
  { label: "Entraram no grupo", value: 0, percent: 0 },
  { label: "Assistiram à live", value: 0, percent: 0 },
  { label: "Qualificados", value: 0, percent: 0 },
  { label: "Viraram clientes", value: 0, percent: 0 },
];

export const demoClients: CrmClient[] = [];
