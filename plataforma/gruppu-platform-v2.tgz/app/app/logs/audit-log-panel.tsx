"use client";

import { useEffect, useMemo, useState } from "react";
import { readAuditLogs, subscribeAuditLogs, type AuditLog } from "../../../lib/crm/audit-store";

export default function AuditLogPanel() {
  const [logs, setLogs] = useState<AuditLog[]>([]); const [search, setSearch] = useState("");
  useEffect(() => { const refresh = () => setLogs(readAuditLogs()); queueMicrotask(refresh); return subscribeAuditLogs(refresh); }, []);
  const visible = useMemo(() => logs.filter((log) => `${log.actor} ${log.action} ${log.entity} ${log.details}`.toLowerCase().includes(search.toLowerCase())), [logs, search]);
  return <section className="crm-panel audit-panel"><div className="leads-toolbar audit-toolbar"><label><span>⌕</span><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Buscar pessoa, ação ou registro" /></label></div>{visible.length === 0 ? <div className="empty-state">Nenhuma alteração registrada ainda.</div> : <div className="audit-list">{visible.map((log) => <article key={log.id}><i>↗</i><div><strong>{log.action}</strong><p>{log.entity} · {log.details}</p></div><span><b>{log.actor}</b><small>{new Date(log.createdAt).toLocaleString("pt-BR")}</small></span></article>)}</div>}</section>;
}
