"use client";

import { useEffect, useMemo, useState } from "react";
import type { DemoLead, LeadStatus } from "../demo-data";
import { readLocalLeads, subscribeToLocalLeads, updateLocalLead } from "../../../lib/crm/local-store";
import ExportButton from "../_components/export-button";

export default function LeadsTable({ leads }: { leads: DemoLead[] }) {
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("Todos");
  const [capturedLeads, setCapturedLeads] = useState<DemoLead[]>([]);
  const [stages, setStages] = useState<Record<string, LeadStatus>>(() => Object.fromEntries(leads.map((lead) => [lead.id, lead.status])));
  const allLeads = useMemo(() => [...capturedLeads, ...leads], [capturedLeads, leads]);
  const visible = useMemo(() => allLeads.filter((lead) => {
    const matchesSearch = `${lead.name} ${lead.email} ${lead.phone}`.toLowerCase().includes(search.toLowerCase());
    return matchesSearch && (status === "Todos" || (stages[lead.id] || lead.status) === status);
  }), [allLeads, search, status, stages]);

  useEffect(() => {
    const refresh = () => {
      const local = readLocalLeads();
      setCapturedLeads(local);
      setStages((current) => ({ ...Object.fromEntries(local.map((lead) => [lead.id, lead.status])), ...current }));
    };
    refresh();
    return subscribeToLocalLeads(refresh);
  }, []);

  function changeStage(lead: DemoLead, next: LeadStatus) {
    setStages((current) => ({ ...current, [lead.id]: next }));
    if (lead.createdAt) updateLocalLead(lead.id, { status: next });
  }

  return (
    <article className="crm-panel leads-panel">
      <div className="leads-toolbar">
        <label><span>⌕</span><input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar por nome, telefone ou e-mail" /></label>
        <select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Filtrar por etapa">
          <option>Todos</option><option>Novo</option><option>Contatado</option><option>Qualificado</option><option>Cliente</option><option>Não compareceu</option>
        </select>
        <ExportButton rows={visible as unknown as Record<string, unknown>[]} fileName="leads-gruppu.csv" columns={[{ key: "name", label: "Nome" }, { key: "phone", label: "Telefone" }, { key: "email", label: "E-mail" }, { key: "revenue", label: "Faturamento" }, { key: "goal", label: "O que quer melhorar" }, { key: "source", label: "Origem" }, { key: "status", label: "Etapa" }, { key: "registeredAt", label: "Entrada" }]} />
      </div>
      <div className="leads-table-wrap">
        <table>
          <thead><tr><th>CONTATO</th><th>FATURAMENTO</th><th>INTERESSE</th><th>ORIGEM</th><th>ETAPA</th><th>ENTRADA</th><th /></tr></thead>
          <tbody>
            {visible.map((lead) => (
              <tr key={lead.id}>
                <td><div className="lead-contact"><span className="lead-avatar">{lead.initials}</span><div><strong>{lead.name}</strong><small>{lead.phone}</small></div></div></td>
                <td>{lead.revenue.replace("/mês", "")}</td><td>{lead.goal || "—"}</td><td>{lead.source}</td>
                <td><select className={`inline-stage status-${(stages[lead.id] || lead.status).toLowerCase().replaceAll(" ", "-")}`} value={stages[lead.id] || lead.status} onChange={(e) => changeStage(lead, e.target.value as LeadStatus)} aria-label={`Etapa de ${lead.name}`}><option>Novo</option><option>Contatado</option><option>Qualificado</option><option>Cliente</option><option>Não compareceu</option></select></td>
                <td>{lead.registeredAt}</td><td><a className="table-action" href={`/app/leads/${lead.id}`}>Abrir →</a></td>
              </tr>
            ))}
          </tbody>
        </table>
        {visible.length === 0 && <p className="empty-state">Nenhum lead encontrado com esses filtros.</p>}
      </div>
    </article>
  );
}
