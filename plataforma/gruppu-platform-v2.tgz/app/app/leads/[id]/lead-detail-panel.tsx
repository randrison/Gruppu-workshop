"use client";

import { FormEvent, useEffect, useState } from "react";
import type { DemoLead, LeadStatus } from "../../demo-data";
import type { LeadActivity, LeadProposal } from "../../../../lib/crm/types";
import { addLocalLeadActivity, addLocalLeadProposal, deleteLocalLeadActivity, findLocalLead, updateLocalLead } from "../../../../lib/crm/local-store";
import { recordAuditLog } from "../../../../lib/crm/audit-store";

const tabs = ["Resumo", "Atividades", "Financeiro", "Anotações"] as const;
type Tab = typeof tabs[number];

export default function LeadDetailPanel({ lead, leadId }: { lead?: DemoLead; leadId: string }) {
  const [currentLead, setCurrentLead] = useState<DemoLead | undefined>(lead);
  const [stage, setStage] = useState<LeadStatus>(lead?.status ?? "Novo");
  const [activeTab, setActiveTab] = useState<Tab>("Resumo");
  const [notes, setNotes] = useState<string[]>(lead?.notes ?? ["Demonstrou interesse em melhorar o cardápio antes da próxima live."]);
  const [note, setNote] = useState("");
  const [activities, setActivities] = useState<LeadActivity[]>(lead?.activities ?? []);
  const [proposals, setProposals] = useState<LeadProposal[]>(lead?.proposals ?? []);
  const [activityOpen, setActivityOpen] = useState(false);
  const [proposalOpen, setProposalOpen] = useState(false);
  const [emailOpen, setEmailOpen] = useState(false);
  const [activityType, setActivityType] = useState<LeadActivity["type"]>("WhatsApp");
  const [activityTitle, setActivityTitle] = useState("");
  const [activityDescription, setActivityDescription] = useState("");
  const [proposalTitle, setProposalTitle] = useState("Gestão estratégica iFood");
  const [proposalAmount, setProposalAmount] = useState("0");
  const [proposalDescription, setProposalDescription] = useState("Gestão e acompanhamento mensal da operação no iFood.");
  const [emailSubject, setEmailSubject] = useState("Próximos passos com a Gruppu");
  const [emailBody, setEmailBody] = useState("");
  const [attachmentName, setAttachmentName] = useState("");

  useEffect(() => {
    if (lead) return;
    const localLead = findLocalLead(leadId);
    if (localLead) {
      queueMicrotask(() => {
        setCurrentLead(localLead);
        setStage(localLead.status);
        setNotes(localLead.notes ?? []);
        setActivities(localLead.activities ?? []);
        setProposals(localLead.proposals ?? []);
      });
    }
  }, [lead, leadId]);

  if (!currentLead) return <section className="crm-panel lead-missing"><h2>Contato não encontrado.</h2><p>Volte para a lista de leads e tente novamente.</p></section>;

  const whatsappPhone = currentLead.phone.replace(/\D/g, "");
  const localLeadId = currentLead.createdAt ? currentLead.id : undefined;

  function addNote(event: FormEvent) {
    event.preventDefault();
    if (!note.trim()) return;
    const nextNotes = [note.trim(), ...notes];
    setNotes(nextNotes);
    if (localLeadId) updateLocalLead(localLeadId, { notes: nextNotes });
    recordAuditLog({ action: "Anotação criada", entity: currentLead?.name ?? "Contato", details: note.trim() });
    setNote("");
  }

  function registerActivity(event: FormEvent) {
    event.preventDefault();
    if (!activityTitle.trim()) return;
    const activity: Omit<LeadActivity, "id"> = { type: activityType, title: activityTitle.trim(), description: activityDescription.trim(), occurredAt: new Date().toISOString() };
    const savedActivity = localLeadId ? addLocalLeadActivity(localLeadId, activity) : undefined;
    const localActivity: LeadActivity = savedActivity ?? { ...activity, id: `activity-${Date.now()}` };
    setActivities((items) => [localActivity, ...items]);
    recordAuditLog({ action: "Atividade registrada", entity: currentLead?.name ?? "Contato", details: `${activityType}: ${activityTitle.trim()}` });
    setActivityTitle(""); setActivityDescription(""); setActivityOpen(false);
  }

  function removeActivity(activityId: string) {
    setActivities((items) => items.filter((item) => item.id !== activityId));
    if (localLeadId) deleteLocalLeadActivity(localLeadId, activityId);
    recordAuditLog({ action: "Atividade excluída", entity: currentLead?.name ?? "Contato", details: activityId });
  }

  function editActivity(activity: LeadActivity) {
    const title = window.prompt("Título da atividade", activity.title);
    if (title === null || !title.trim()) return;
    const description = window.prompt("Descrição da atividade", activity.description) ?? activity.description;
    const nextActivities = activities.map((item) => item.id === activity.id ? { ...item, title: title.trim(), description: description.trim() } : item);
    setActivities(nextActivities);
    if (localLeadId) updateLocalLead(localLeadId, { activities: nextActivities });
    recordAuditLog({ action: "Atividade editada", entity: currentLead?.name ?? "Contato", details: title.trim() });
  }

  function createProposal(event: FormEvent) {
    event.preventDefault();
    const proposal: Omit<LeadProposal, "id" | "createdAt" | "status"> = { title: proposalTitle.trim(), amount: Number(proposalAmount) || 0, description: proposalDescription.trim() };
    const savedProposal = localLeadId ? addLocalLeadProposal(localLeadId, proposal) : undefined;
    const localProposal: LeadProposal = savedProposal ?? { ...proposal, id: `proposal-${Date.now()}`, createdAt: new Date().toISOString(), status: "Rascunho" };
    setProposals((items) => [localProposal, ...items]);
    recordAuditLog({ action: "Proposta criada", entity: currentLead?.name ?? "Contato", details: `${proposalTitle} · R$ ${proposal.amount}` });
    setProposalOpen(false);
  }

  function openEmail() {
    const attachmentNotice = attachmentName ? `\n\nAnexo selecionado: ${attachmentName} (anexe o arquivo no seu aplicativo de e-mail antes de enviar).` : "";
    window.location.href = `mailto:${currentLead?.email ?? ""}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(`${emailBody}${attachmentNotice}`)}`;
  }

  function printProposal(proposal: LeadProposal) {
    const popup = window.open("", "_blank", "width=860,height=720");
    if (!popup) return;
    const safe = (value: string) => value.replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character] || character);
    popup.document.write(`<html><head><title>Proposta Gruppu</title><style>body{font-family:Arial;padding:55px;color:#111}header{border-bottom:4px solid #ed2028;padding-bottom:20px}h1{font-size:42px}strong{font-size:34px;color:#ed2028}p{line-height:1.7}footer{margin-top:70px;border-top:1px solid #ddd;padding-top:20px;color:#777}@media print{button{display:none}}</style></head><body><header><b>GRUPPU.</b></header><h1>${safe(proposal.title)}</h1><p>Preparada para <b>${safe(currentLead?.name ?? "Contato")}</b></p><strong>${proposal.amount.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}/mês</strong><p>${safe(proposal.description)}</p><footer>Proposta comercial · Gruppu Gestão Estratégica iFood</footer><button onclick="window.print()">Salvar como PDF / imprimir</button></body></html>`);
    popup.document.close();
  }

  return (
    <>
      <section className="lead-command-bar crm-panel">
        <div><span>ETAPA ATUAL</span><select value={stage} onChange={(e) => { const next = e.target.value as LeadStatus; setStage(next); if (currentLead.createdAt) updateLocalLead(currentLead.id, { status: next }); recordAuditLog({ action: "Etapa do lead alterada", entity: currentLead.name, details: `${stage} → ${next}` }); }}><option>Novo</option><option>Contatado</option><option>Qualificado</option><option>Cliente</option><option>Não compareceu</option></select></div>
        <p><i /> Alterações salvas automaticamente nesta demonstração</p>
        <div className="lead-command-actions"><a target="_blank" rel="noreferrer" href={`https://wa.me/55${whatsappPhone}?text=Oi%20${encodeURIComponent(currentLead.name.split(" ")[0])}%2C%20aqui%20%C3%A9%20da%20Gruppu!`}>WhatsApp ↗</a><button type="button" onClick={() => setEmailOpen((value) => !value)}>Escrever e-mail</button></div>
      </section>

      {emailOpen && <form className="crm-panel crm-action-form email-composer" onSubmit={(event) => { event.preventDefault(); openEmail(); }}><div><span>E-MAIL PARA {currentLead.name.toUpperCase()}</span><h2>Escreva a mensagem antes de enviar</h2></div><label>Assunto<input value={emailSubject} onChange={(event) => setEmailSubject(event.target.value)} required /></label><label>Mensagem<textarea value={emailBody} onChange={(event) => setEmailBody(event.target.value)} placeholder="Olá, quero confirmar sua participação na próxima análise..." required /></label><label className="file-field">PDF opcional<input type="file" accept="application/pdf" onChange={(event) => setAttachmentName(event.target.files?.[0]?.name ?? "")} /><small>{attachmentName || "O arquivo será anexado manualmente no aplicativo de e-mail."}</small></label><div><button type="button" className="button-muted" onClick={() => setEmailOpen(false)}>Cancelar</button><button type="submit">Abrir no e-mail →</button></div></form>}

      <nav className="lead-tabs" aria-label="Seções do contato">{tabs.map((tab) => <button key={tab} className={activeTab === tab ? "active" : ""} onClick={() => setActiveTab(tab)}>{tab}</button>)}</nav>

      {activeTab === "Resumo" && <section className="lead-detail-grid">
        <article className="crm-panel lead-profile">
          <div className="lead-profile-head"><span className="lead-avatar large">{currentLead.initials}</span><div><h2>{currentLead.name}</h2><b className={`status status-${stage.toLowerCase().replaceAll(" ", "-")}`}>{stage}</b></div><span className="lead-score"><small>SCORE</small>{currentLead.score}</span></div>
          <dl><div><dt>Telefone</dt><dd>{currentLead.phone}</dd></div><div><dt>E-mail</dt><dd>{currentLead.email}</dd></div><div><dt>Faturamento atual</dt><dd>{currentLead.revenue}</dd></div><div><dt>Principal objetivo</dt><dd>{currentLead.goal}</dd></div><div><dt>Origem</dt><dd>{currentLead.source}</dd></div><div><dt>Workshop</dt><dd>{currentLead.workshop}</dd></div></dl>
        </article>
        <div className="lead-side-stack"><article className="crm-panel potential-card"><span>POTENCIAL ESTIMADO</span><strong>{currentLead.potential}</strong><p>Receita mensal estimada para a Gruppu se esta oportunidade virar cliente.</p></article><article className="crm-panel next-action-card"><span>PRÓXIMA AÇÃO</span><h2>Confirmar presença na live</h2><p>Prazo: hoje às 14h</p><button onClick={() => setActiveTab("Atividades")}>Ver histórico completo →</button></article></div>
      </section>}

      {activeTab === "Atividades" && <section className="crm-panel activity-panel"><div className="crm-panel-head"><div><span>HISTÓRICO COMPLETO</span><h2>Interações com este contato</h2></div><button onClick={() => setActivityOpen((value) => !value)}>+ Registrar atividade</button></div>{activityOpen && <form className="inline-activity-form" onSubmit={registerActivity}><select value={activityType} onChange={(event) => setActivityType(event.target.value as LeadActivity["type"])}><option>Ligação</option><option>WhatsApp</option><option>E-mail</option><option>Reunião</option><option>Observação</option></select><input value={activityTitle} onChange={(event) => setActivityTitle(event.target.value)} placeholder="Título da atividade" required /><textarea value={activityDescription} onChange={(event) => setActivityDescription(event.target.value)} placeholder="O que aconteceu?" /><button type="submit">Salvar atividade</button></form>}<ol>{activities.map((activity) => <li className="done custom-activity" key={activity.id}><i>✓</i><div><strong>{activity.type}: {activity.title}</strong><p>{new Date(activity.occurredAt).toLocaleString("pt-BR")} · {activity.description || "Sem observação"}</p></div><div className="activity-row-actions"><button onClick={() => editActivity(activity)}>Editar</button><button aria-label="Excluir atividade" onClick={() => removeActivity(activity.id)}>Excluir</button></div></li>)}<li className="done"><i>✓</i><div><strong>Cadastro recebido pela página de captura</strong><p>{currentLead.registeredAt} · Origem: {currentLead.source}</p></div></li><li className={currentLead.groupClickedAt ? "done" : ""}><i>{currentLead.groupClickedAt ? "✓" : "○"}</i><div><strong>{currentLead.groupClickedAt ? "Clicou para abrir o grupo do WhatsApp" : "Clique no grupo ainda não registrado"}</strong><p>O clique não confirma que a pessoa entrou no grupo.</p></div></li><li><i>↗</i><div><strong>Mensagem de confirmação preparada</strong><p>Aguardando conexão com a API oficial do WhatsApp.</p></div></li><li><i>○</i><div><strong>Presença na live</strong><p>Aguardando a próxima segunda-feira, às 16h</p></div></li></ol></section>}

      {activeTab === "Financeiro" && <><section className="lead-financial-grid"><article className="crm-panel financial-card primary"><span>VALOR POTENCIAL MENSAL</span><strong>{currentLead.potential}</strong><p>Começa zerado e pode ser atualizado depois.</p></article><article className="crm-panel financial-card"><span>VALOR POTENCIAL EM 12 MESES</span><strong>R$ 0</strong><p>Sem estimativa cadastrada.</p></article><article className="crm-panel financial-card"><span>PROPOSTAS</span><strong>{proposals.length}</strong><p>Crie uma proposta e salve como PDF.</p><button onClick={() => setProposalOpen((value) => !value)}>Criar proposta →</button></article></section>{proposalOpen && <form className="crm-panel crm-action-form proposal-form" onSubmit={createProposal}><div><span>NOVA PROPOSTA</span><h2>Monte a proposta comercial</h2></div><label>Título<input value={proposalTitle} onChange={(event) => setProposalTitle(event.target.value)} required /></label><label>Mensalidade (R$)<input type="number" min="0" step="0.01" value={proposalAmount} onChange={(event) => setProposalAmount(event.target.value)} /></label><label>Escopo<textarea value={proposalDescription} onChange={(event) => setProposalDescription(event.target.value)} /></label><button type="submit">Salvar proposta</button></form>}{proposals.length > 0 && <section className="proposal-list">{proposals.map((proposal) => <article className="crm-panel" key={proposal.id}><span>{proposal.status}</span><h3>{proposal.title}</h3><strong>{proposal.amount.toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}/mês</strong><p>{proposal.description}</p><button onClick={() => printProposal(proposal)}>Salvar PDF / imprimir</button></article>)}</section>}</>}

      {activeTab === "Anotações" && <section className="notes-grid"><form className="crm-panel notes-form" onSubmit={addNote}><span>NOVA ANOTAÇÃO</span><h2>O que a equipe precisa saber?</h2><textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Ex.: pediu retorno na terça após as 10h..." /><button type="submit">Salvar anotação</button></form><article className="crm-panel notes-list"><div className="crm-panel-head"><div><span>ANOTAÇÕES DA EQUIPE</span><h2>Histórico interno</h2></div></div>{notes.map((item, index) => <div key={`${item}-${index}`}><strong>{index === 0 ? "Agora" : "03/08, 11:20"}</strong><p>{item}</p><small>Equipe Gruppu</small></div>)}</article></section>}
    </>
  );
}
