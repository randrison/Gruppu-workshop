import { NextResponse } from "next/server";
import { integrationCatalog } from "../../../../lib/integrations/catalog";

export async function GET() {
  const status = Object.fromEntries(integrationCatalog.map((integration) => {
    const configuredCount = integration.env.filter((key) => Boolean(process.env[key])).length;
    return [integration.id, { configured: integration.env.length === 0 || configuredCount === integration.env.length, configuredCount, total: integration.env.length }];
  }));
  return NextResponse.json(status, { headers: { "cache-control": "no-store" } });
}
