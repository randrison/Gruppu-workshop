"use client";

import { FormEvent, useCallback, useState } from "react";
import { createLocalLead, markLocalLeadGroupClick } from "../lib/crm/local-store";
import type { LeadAttribution } from "../lib/crm/types";
import RecaptchaV2 from "@/components/recaptcha-v2";

const whatsappGroupUrl = "https://wa.link/2l776l";

export default function Home() {
  const [sending, setSending] = useState(false);
  const [goalWarning, setGoalWarning] = useState(false);
  const [phone, setPhone] = useState("");
  const [captchaToken, setCaptchaToken] = useState("");
  const [formError, setFormError] = useState("");
  const handleCaptcha = useCallback((token: string) => setCaptchaToken(token), []);

  function formatPhone(value: string) {
    const digits = value.replace(/\D/g, "").slice(0, 11);
    if (digits.length <= 2) return digits ? `(${digits}` : "";
    if (digits.length <= 7) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setFormError("");
    const form = event.currentTarget;
    const hasGoal = form.querySelector<HTMLInputElement>('input[name="goal"]:checked');
    if (!hasGoal) {
      setGoalWarning(true);
      form.querySelector<HTMLElement>("fieldset")?.focus();
      return;
    }
    if (phone.replace(/\D/g, "").length !== 11) {
      setFormError("Digite um celular completo com DDD e 9 dígitos.");
      return;
    }
    if (!captchaToken) {
      setFormError("Marque a proteção “Não sou um robô” para continuar.");
      return;
    }
    setSending(true);
    const captchaResponse = await fetch("/api/recaptcha", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ token: captchaToken }) });
    if (!captchaResponse.ok) {
      setSending(false);
      setFormError("Não conseguimos validar a proteção. Atualize a página e tente novamente.");
      return;
    }
    const data = new FormData(form);
    const params = new URLSearchParams(window.location.search);
    const attribution: LeadAttribution = {
      source: params.get("utm_source") || params.get("origem") || undefined,
      medium: params.get("utm_medium") || undefined,
      campaign: params.get("utm_campaign") || undefined,
      content: params.get("utm_content") || undefined,
      term: params.get("utm_term") || undefined,
      gclid: params.get("gclid") || undefined,
      fbclid: params.get("fbclid") || undefined,
      landingPage: `${window.location.pathname}${window.location.search}`,
      referrer: document.referrer || undefined,
    };
    const lead = createLocalLead({
      name: String(data.get("name") || ""),
      phone: String(data.get("phone") || ""),
      email: String(data.get("email") || ""),
      revenue: String(data.get("revenue") || ""),
      goals: data.getAll("goal").map(String),
      consentEmail: data.get("consentPrivacy") === "on",
      consentWhatsapp: true,
      consentPrivacy: data.get("consentPrivacy") === "on",
      attribution,
    });
    window.setTimeout(() => {
      markLocalLeadGroupClick(lead.id);
      window.location.href = whatsappGroupUrl;
    }, 650);
  }

  return (
    <main className="page-shell">
      <div className="glow glow-one" aria-hidden="true" />
      <div className="glow glow-two" aria-hidden="true" />

      <header className="site-header">
        <a className="brand" href="#top" aria-label="Gruppu — início">
          GRUPPU<span className="brand-dot">.</span>
        </a>
        <nav className="site-nav" aria-label="Navegação principal">
          <span className="header-note">
            <span className="live-dot" aria-hidden="true" />
            Evento gratuito
          </span>
        </nav>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <div className="eyebrow">
            <span>ANÁLISE DE LOJA AO VIVO</span>
          </div>

          <h1>
            Vou analisar sua loja <em>ao vivo</em> e mostrar como vender
            <strong> R$20 mil a mais no iFood.</strong>
          </h1>

          <p className="lead">
            Sem gastar mais com anúncios ou promoções. Vamos abrir lojas reais,
            encontrar os gargalos e mostrar os ajustes que aumentam vendas,
            lucro e previsibilidade.
          </p>

          <a className="mobile-cta" href="#cadastro">
            Quero participar <span aria-hidden="true">↓</span>
          </a>

          <div className="event-card">
            <div className="calendar-block" aria-hidden="true">
              <span>SEG</span>
              <strong>16h</strong>
            </div>
            <div>
              <span className="event-label">PRÓXIMA EDIÇÃO</span>
              <h2>Segunda-feira, às 16h</h2>
              <p>Ao vivo. Direto ao ponto. Aplicável no mesmo dia.</p>
            </div>
          </div>

          <div className="proof-row" aria-label="Resultados da Gruppu">
            <div>
              <strong>+R$4 mi</strong>
              <span>em vendas geradas</span>
            </div>
            <div>
              <strong>+370</strong>
              <span>lojas atendidas</span>
            </div>
            <div>
              <strong>Brasil</strong>
              <span>clientes de ponta a ponta</span>
            </div>
          </div>
        </div>

        <aside className="form-card" id="cadastro" aria-labelledby="form-title">
          <div className="form-topline">
            <span className="step-number">01</span>
            <span>GARANTA SEU ACESSO</span>
          </div>
          <h2 id="form-title">Receba o link da análise.</h2>
          <p className="form-intro">
            É simples e leva menos de 1 minuto. Depois do cadastro, você entra
            no grupo oficial do WhatsApp.
          </p>

          <form onSubmit={handleSubmit}>
            <label htmlFor="name">Nome</label>
            <input id="name" name="name" type="text" placeholder="Digite seu nome" autoComplete="name" required />

            <label htmlFor="phone">Telefone</label>
            <input id="phone" name="phone" type="tel" placeholder="(31) 99999-9999" autoComplete="tel" inputMode="numeric" pattern="\(\d{2}\) \d{5}-\d{4}" maxLength={15} value={phone} onChange={(event) => setPhone(formatPhone(event.target.value))} required />

            <label htmlFor="email">E-mail</label>
            <input id="email" name="email" type="email" placeholder="Digite seu melhor e-mail" autoComplete="email" required />

            <label htmlFor="revenue">Quanto sua loja vende hoje no iFood?</label>
            <div className="select-wrap">
              <select id="revenue" name="revenue" defaultValue="" required>
                <option value="" disabled>Selecione uma faixa de faturamento</option>
                <option>Até R$ 20 mil/mês</option>
                <option>De R$ 20 mil a R$ 50 mil/mês</option>
                <option>De R$ 50 mil a R$ 100 mil/mês</option>
                <option>Acima de R$ 100 mil/mês</option>
              </select>
            </div>

            <fieldset tabIndex={-1} aria-describedby={goalWarning ? "goal-error" : undefined}>
              <legend>O que você quer melhorar? <small>Ative uma ou mais opções.</small></legend>
              <label className="switch-row">
                <input type="checkbox" name="goal" value="vendas" onChange={() => setGoalWarning(false)} />
                <span className="switch" aria-hidden="true" />
                <span>Vender mais sem depender de promoções</span>
              </label>
              <label className="switch-row">
                <input type="checkbox" name="goal" value="cardapio" onChange={() => setGoalWarning(false)} />
                <span className="switch" aria-hidden="true" />
                <span>Melhorar meu cardápio atual</span>
              </label>
              <label className="switch-row">
                <input type="checkbox" name="goal" value="analise" onChange={() => setGoalWarning(false)} />
                <span className="switch" aria-hidden="true" />
                <span>Participar da análise ao vivo</span>
              </label>
              {goalWarning && <p className="field-error" id="goal-error">Ative pelo menos uma opção para continuar.</p>}
            </fieldset>

            <label className="consent-row consent-required">
              <input type="checkbox" name="consentPrivacy" required />
              <span>Li e concordo com a <a href="/politica-de-privacidade" target="_blank">Política de Privacidade</a> e autorizo o envio do link e dos avisos da análise.</span>
            </label>

            <RecaptchaV2 onToken={handleCaptcha} />
            {formError && <p className="field-error form-error" role="alert">{formError}</p>}

            <button type="submit" disabled={sending}>
              <span>{sending ? "ABRINDO O GRUPO..." : "ENTRAR NO GRUPO DO WHATSAPP"}</span>
            </button>
          </form>
        </aside>
      </section>

      <footer className="landing-footer">
        <div>
          <strong>GRUPPU — GESTÃO ESTRATÉGICA IFOOD</strong>
          <span>Gruppu Gruppu LTDA · CNPJ 55.404.170/0001-23</span>
        </div>
        <address>
          Avenida Paulista, 302, Conj. 10<br />
          Bela Vista · São Paulo/SP · CEP 01310-000
        </address>
        <nav aria-label="Informações legais">
          <a href="/politica-de-privacidade">Política de Privacidade</a>
          <span>@gruppu_</span>
        </nav>
      </footer>
    </main>
  );
}
